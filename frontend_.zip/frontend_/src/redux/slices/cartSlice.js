import { createSlice } from '@reduxjs/toolkit';
import axiosInstance from '../../api/axiosInstance';
import fashionRoundNeckTshirt from '../../images/fashion_round_neck_tshirt.avif';
import iphone15 from '../../images/iphone15.png';
import crop from '../../images/crop.jpg';
import electronicsTV from '../../images/electronics_tv.jpg';
import fashionTshirt from '../../images/fashion_tshirt.jpg';
import homeSofa from '../../images/home_sofa.jpg';

const initialState = {
  items: [],
  status: 'idle', 
  error: null,
};

const defaultImagePath = 'path/to/default/image.jpg'; 

const productImages = {
    1: fashionRoundNeckTshirt,
    2: iphone15,
    3: crop,
    4: electronicsTV,
    5: fashionTshirt,
    11: homeSofa,
};

const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    setCartItems(state, action) {
      state.items = action.payload;
    },
    addToCart(state, action) {
      const existingItemIndex = state.items.findIndex(item => item.id === action.payload.id);
      if (existingItemIndex >= 0) {
        state.items[existingItemIndex].quantity += action.payload.quantity; 
      } else {
        state.items.push(action.payload); 
      }
    },
    updateCartItem(state, action) {
      const itemIndex = state.items.findIndex((item) => item.id === action.payload.id);
      if (itemIndex >= 0) {
        state.items[itemIndex].quantity = action.payload.quantity; 
      }
    },
    removeFromCart(state, action) {
      state.items = state.items.filter((item) => item.id !== action.payload);
    },
  },
});

export const { setCartItems, addToCart, updateCartItem, removeFromCart } = cartSlice.actions;
export default cartSlice.reducer;

export const fetchCartItems = () => async (dispatch) => {
  try {
    const response = await axiosInstance.get('/users/cart/items');
    const cartItems = response.data.map(item => {
      const imageUrl = productImages[item.productId] || defaultImagePath;
      return {
        ...item,
        id: item.productId,
        image: imageUrl,
      };
    });
    dispatch(setCartItems(cartItems));
  } catch (error) {
    console.error('Error fetching cart items:', error);
  }
};

export const addToCartAction = (productId, quantity) => async (dispatch) => {
  try {
    const response = await axiosInstance.post(`/users/cart/addToCart?productId=${productId}&quantity=${quantity}`);
    
    // Make sure response.data has correct properties
    const newItem = {
      id: response.data.productId,  // Ensure productId is used for 'id'
      quantity: response.data.quantity,  // Set the quantity correctly
      image: productImages[response.data.productId] || defaultImagePath  // Add image if available
    };

    dispatch(addToCart(newItem));
  } catch (error) {
    console.error('Error adding to cart:', error);
  }
};


export const updateCartItemAction = (id, quantity) => async (dispatch) => {
  try {
    const response = await axiosInstance.put(`/users/cart/updateCart?productId=${id}&quantity=${quantity}`);
    dispatch(updateCartItem({ id: response.data.id, quantity: response.data.quantity }));
  } catch (error) {
    console.error('Error updating cart item:', error);
  }
};

export const removeFromCartAction = (id) => async (dispatch) => {
  try {
    await axiosInstance.delete(`/users/cart/removeItem?productId=${id}`);
    dispatch(removeFromCart(id));
  } catch (error) {
    console.error('Error removing from cart:', error);
  }
};

