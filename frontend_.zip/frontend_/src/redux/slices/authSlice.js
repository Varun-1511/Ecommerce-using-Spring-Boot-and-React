import { createSlice } from '@reduxjs/toolkit';
import axiosInstance from '../../api/axiosInstance';

const authSlice = createSlice({
  name: 'auth',
  initialState: { isAuthenticated: false, user: null, token: null },
  reducers: {
    setAuth(state, action) {
      state.isAuthenticated = true;
      state.user = action.payload.user;
      state.token = action.payload.token;
      localStorage.setItem('token', action.payload.token);  // Save JWT token
    },
    logout(state) {
      state.isAuthenticated = false;
      state.user = null;
      state.token = null;
      localStorage.removeItem('token');  // Clear JWT token
    }
  }
});

export const { setAuth, logout } = authSlice.actions;

export const login = (credentials) => async (dispatch) => {
  try {
    const response = await axiosInstance.post('/auth/generateToken', credentials);
    dispatch(setAuth({ user: response.data.user, token: response.data.token }));
  } catch (error) {
    console.error('Login error:', error);
  }
};

export default authSlice.reducer;
