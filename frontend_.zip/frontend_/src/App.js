import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';
import HomePage from './Pages/HomePage';
import LoginPage from './Pages/LoginPage';
import RegisterPage from './Pages/RegisterPage';
import CartPage from './Pages/CartPage';
import SellerDashboard from './Pages/SellerDashboard';
import AdminDashboard from './Pages/AdminDashboard';
import ProtectedRoute from './Components/ProtectedRoute';
import Navbar from './Components/Navbar';
import Footer from './Components/Footer'; 
import AboutUs from './Components/AboutUs';
import ContactUs from './Components/ContactUs';
import PrivacyPolicy from './Components/PrivacyPolicy';
import TermsOfService from './Components/TermsOfService';
import ProductCard from './Components/ProductCard';
import AddressPage from './Pages/AdressPage';
import PaymentPage from './Pages/PaymentPage';
import AdminLogin from './Pages/AdminLogin';
import AdminUsers from './Components/AdminUsers';
import AdminProducts from './Components/AdminProducts';
import UserProfile from './Components/UserProfile';
import SellerLogin from './Pages/SellerLogin';
import SellerRegister from './Pages/SellerRegister';

const App = () => {
  const location = useLocation();

  const hideFooterPaths = ['/about-us', '/contact-us', '/privacy-policy', '/terms-of-service'];

  return (
    <>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<LoginPage />} />
        {/* <Route path="/register" element={<RegisterPage />} /> */}
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/cart" element={<CartPage />} />
        <Route path="/seller-dashboard" element={<SellerDashboard />} />
        <Route path="/admin-dashboard" element={<AdminDashboard />} />
        <Route path="/admin-login" element={<AdminLogin />} />
        <Route path="/admin-users" element={<AdminUsers />} />
        <Route path="/admin-products" element={<AdminProducts />} />
        <Route path="/about-us" element={<AboutUs />} />
        <Route path="/contact-us" element={<ContactUs />} />
        <Route path="/privacy-policy" element={<PrivacyPolicy />} />
        <Route path="/terms-of-service" element={<TermsOfService />} />
        <Route path="/product/:id" element={<ProductCard />} />
        <Route path="/fetchProductDetails/:id" element={<ProductCard />} />
        <Route path="/address" element={<AddressPage />} />
        <Route path="/payment" element={<PaymentPage />} />
        <Route path="/user-profile" element={<UserProfile />} />
        <Route path="/seller-login" element={<SellerLogin />} />
      <Route path="/seller-Register" element={<SellerRegister />} />
        
      </Routes>
      {/* {!hideFooterPaths.includes(location.pathname) && <Footer />} */}
    </>
  );
}

export default App;
