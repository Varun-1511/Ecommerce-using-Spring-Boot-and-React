import React from 'react';
import { Drawer, List, ListItem, ListItemText, Typography, Box, Button } from '@mui/material';
import { Link, useNavigate } from 'react-router-dom';

const Sidebar = () => {
  const navigate = useNavigate();

  // Handle logout
  const handleLogout = () => {
    // Clear the admin token or any session data here
    localStorage.removeItem('adminToken');
    // Navigate to the home page
    navigate('/');
  };

  return (
    <Drawer
      variant="permanent"
      anchor="left"
      sx={{
        width: 240,
        flexShrink: 0,
        '& .MuiDrawer-paper': {
          width: 240,
          boxSizing: 'border-box',
          backgroundColor: '#2c3e50', // Dark background
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between', // Align items and footer at the bottom
        },
      }}
    >
      {/* Header Section */}
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '20px 0',
          backgroundColor: '#34495e', // Slightly darker top section
        }}
      >
        <Typography variant="h5" sx={{ color: '#ecf0f1', fontWeight: 'bold' }}>
          Admin Panel
        </Typography>
      </Box>

      {/* Main List Section */}
      <List sx={{ flexGrow: 1 }}>
        <ListItem
          button
          component={Link}
          to="/admin-dashboard"
          sx={{
            '&:hover': { backgroundColor: '#1abc9c' }, // Hover effect with green color
          }}
        >
          <ListItemText primary="Dashboard" sx={{ color: '#ecf0f1' }} />
        </ListItem>

        <ListItem
          button
          component={Link}
          to="/admin-users"
          sx={{
            '&:hover': { backgroundColor: '#1abc9c' }, // Hover effect
          }}
        >
          <ListItemText primary="Users" sx={{ color: '#ecf0f1' }} />
        </ListItem>

        <ListItem
          button
          component={Link}
          to="/admin-products"
          sx={{
            '&:hover': { backgroundColor: '#1abc9c' }, // Hover effect
          }}
        >
          <ListItemText primary="Categories" sx={{ color: '#ecf0f1' }} />
        </ListItem>

        {/* Add more navigation items as needed */}
      </List>

      {/* Logout Button */}
      <Box sx={{ padding: '10px' }}>
        <Button
          variant="contained"
          color="secondary"
          onClick={handleLogout}
          fullWidth
          sx={{
            '&:hover': { backgroundColor: '#e74c3c' }, // Hover effect
          }}
        >
          Logout
        </Button>
      </Box>

      {/* Footer Section */}
      <Box
        sx={{
          padding: '10px',
          textAlign: 'center',
          backgroundColor: '#34495e', // Same as the header for consistency
        }}
      >
        <Typography variant="body2" sx={{ color: '#ecf0f1' }}>
          © 2024 MyCompany
        </Typography>
      </Box>
    </Drawer>
  );
};

export default Sidebar;
