import axios from 'axios';

const placeOrder = async (productId, quantity) => {
    if (quantity < 1) return; 
    try {
        const response = await axios.post('http://localhost:9090/seller/orders/placeorder', null, {
            params: { productid: productId, quantity: quantity },
            headers: {
                'Authorization': 'Bearer ' + localStorage.getItem('token'),
            },
        });

        console.log("Order placed successfully:", response.data); 
        return response.data; 
    } catch (err) {
        console.error("Error placing order: ", err.response ? err.response.data : err); 
        throw new Error("Failed to place order: " + (err.response ? err.response.data.message : err.message)); 
    }
};

export default placeOrder;
