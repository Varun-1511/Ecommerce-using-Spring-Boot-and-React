import React, { useEffect, useState } from 'react';
import {
  Container,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Box,
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import Sidebar from './Sidebar';

const AdminUsers = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchUsers = async () => {
      const token = localStorage.getItem('adminToken');
      if (token) {
        try {
          const response = await fetch('http://localhost:9090/auth/getAllUsers', {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
          if (response.ok) {
            const data = await response.json();
            console.log('Fetched Users:', data); // Log fetched users
            setUsers(data);
          } else {
            console.error('Failed to fetch users:', response.statusText);
          }
        } catch (error) {
          console.error('Error fetching users:', error);
        }
      } else {
        console.error('Token not found');
      }
    };

    fetchUsers();
  }, []);

  const handleDelete = async (uid) => {
    const token = localStorage.getItem('adminToken');
    if (token) {
      try {
        const response = await fetch(`http://localhost:9090/auth/deleteUser/${uid}`, {
          method: 'DELETE',
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (response.ok) {
          // Correctly filter out the deleted user using uid
          setUsers(users.filter((user) => user.uid !== uid));
        } else {
          alert('Failed to delete user.');
        }
      } catch (error) {
        console.error('Error deleting user:', error);
        alert('Failed to delete user.');
      }
    } else {
      console.error('Token not found');
    }
  };

  return (
    <Box sx={{ display: 'flex' }}>
      <Sidebar />
      <Container sx={{ marginLeft: 5, padding: 3 }}>
        <Typography
          variant="h4"
          gutterBottom
          sx={{ color: '#2c3e50', fontWeight: 'bold', marginBottom: 3 }}
        >
          Manage Users
        </Typography>
        <TableContainer component={Paper} sx={{ boxShadow: 3 }}>
          <Table>
            <TableHead sx={{ backgroundColor: '#2c3e50' }}>
              <TableRow>
                <TableCell sx={{ color: '#fff', fontWeight: 'bold' }}>UID</TableCell>
                <TableCell sx={{ color: '#fff', fontWeight: 'bold' }}>Name</TableCell>
                <TableCell sx={{ color: '#fff', fontWeight: 'bold' }}>Email</TableCell>
                <TableCell sx={{ color: '#fff', fontWeight: 'bold' }}>Role</TableCell>
                <TableCell sx={{ color: '#fff', fontWeight: 'bold' }}>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {users.map((user) => (
                <TableRow
                  key={user.uid} // Use uid for the key
                  sx={{
                    '&:hover': {
                      backgroundColor: '#f5f5f5',
                    },
                  }}
                >
                  <TableCell>{user.uid}</TableCell> {/* Display uid */}
                  <TableCell>{user.name}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>
                    {Array.isArray(user.roles) ? user.roles.join(', ') : user.roles}
                  </TableCell>
                  <TableCell>
                    <IconButton
                      onClick={() => handleDelete(user.uid)} // Use uid in the delete function
                      color="secondary"
                      sx={{
                        '&:hover': {
                          color: '#e74c3c',
                        },
                      }}
                    >
                      <DeleteIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        {console.log('Users State:', users)} {/* Log users state */}
      </Container>
    </Box>
  );
};

export default AdminUsers;
