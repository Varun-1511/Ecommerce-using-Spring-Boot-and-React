import React, { useEffect, useState } from 'react';
import {
  Container,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  TextField,
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import Sidebar from './Sidebar';

const AdminProducts = () => {
  const [categories, setCategories] = useState([]);
  const [error, setError] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [currentCategory, setCurrentCategory] = useState(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');

  // Fetch categories from the backend
  useEffect(() => {
    const fetchCategories = async () => {
      const token = localStorage.getItem('adminToken');
      if (token) {
        try {
          const response = await fetch('http://localhost:9090/admin/categories/getCategories', {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });

          if (response.ok) {
            const data = await response.json();
            setCategories(data);
          } else {
            console.error('Failed to fetch categories:', response.statusText);
          }
        } catch (error) {
          console.error('Error fetching categories:', error);
        }
      } else {
        console.error('Token not found');
      }
    };

    fetchCategories();
  }, []);

  // Handle delete request
  const handleDelete = async (id) => {
    const token = localStorage.getItem('adminToken');
    if (token) {
      try {
        const response = await fetch(`http://localhost:9090/admin/categories/deleteCategory/${id}`, {
          method: 'DELETE',
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (response.ok) {
          setCategories(categories.filter((category) => category.id !== id));
        } else {
          alert('Failed to delete category.');
        }
      } catch (error) {
        console.error('Error deleting category:', error);
        alert('Failed to delete category.');
      }
    } else {
      console.error('Token not found');
    }
  };

  // Handle dialog open for adding/updating category
  const handleDialogOpen = (category = null) => {
    if (category) {
      setCurrentCategory(category);
      setName(category.name);
      setDescription(category.description);
    } else {
      setCurrentCategory(null);
      setName('');
      setDescription('');
    }
    setOpenDialog(true);
  };

  // Handle category form submission
  const handleSubmit = async (event) => {
    event.preventDefault();
    const token = localStorage.getItem('adminToken');
    const url = currentCategory
      ? `http://localhost:9090/admin/categories/updateCategory/${currentCategory.id}`
      : 'http://localhost:9090/admin/categories/addCategory';
    const method = currentCategory ? 'PUT' : 'POST';

    if (token) {
      try {
        const response = await fetch(url, {
          method: method,
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ name, description }),
        });

        if (response.ok) {
          const data = await response.json();
          if (method === 'POST') {
            setCategories([...categories, data]);
          } else {
            setCategories(categories.map((cat) => (cat.id === data.id ? data : cat)));
          }
          setOpenDialog(false);
        } else {
          alert('Failed to save category.');
        }
      } catch (error) {
        console.error('Error saving category:', error);
        alert('Failed to save category.');
      }
    } else {
      console.error('Token not found');
    }
  };

  return (
    <Box sx={{ display: 'flex', backgroundColor: '#f4f6f8', minHeight: '100vh' }}>
      <Sidebar />
      <Container sx={{ marginLeft: '80px', padding: 4 }}>
        <Typography variant="h4" gutterBottom sx={{ color: '#2c3e50', fontWeight: 'bold' }}>
          Manage Categories
        </Typography>
        <Button variant="contained" onClick={() => handleDialogOpen()} sx={{ marginBottom: 2 }}>
          Add Category
        </Button>
        <TableContainer component={Paper} sx={{ borderRadius: '8px' }}>
          <Table>
            <TableHead sx={{ backgroundColor: '#2c3e50' }}>
              <TableRow>
                <TableCell sx={{ color: '#fff' }}>ID</TableCell>
                <TableCell sx={{ color: '#fff' }}>Name</TableCell>
                <TableCell sx={{ color: '#fff' }}>Description</TableCell>
                <TableCell sx={{ color: '#fff' }}>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {categories.map((category) => (
                <TableRow key={category.id}>
                  <TableCell>{category.id}</TableCell>
                  <TableCell>{category.name}</TableCell>
                  <TableCell>{category.description}</TableCell>
                  <TableCell>
                    <IconButton
                      onClick={() => handleDialogOpen(category)}
                      color="primary"
                      sx={{
                        '&:hover': {
                          color: '#3f51b5',
                        },
                      }}
                    >
                      <EditIcon />
                    </IconButton>
                    <IconButton
                      onClick={() => handleDelete(category.id)}
                      color="secondary"
                      sx={{
                        '&:hover': {
                          color: '#e74c3c',
                        },
                      }}
                    >
                      <DeleteIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        {/* Dialog for Adding/Updating Category */}
        <Dialog open={openDialog} onClose={() => setOpenDialog(false)}>
          <DialogTitle>{currentCategory ? 'Update Category' : 'Add Category'}</DialogTitle>
          <DialogContent>
            <DialogContentText>
              {currentCategory ? 'Update the category details.' : 'Enter the category details.'}
            </DialogContentText>
            <TextField
              autoFocus
              margin="dense"
              label="Category Name"
              fullWidth
              variant="outlined"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
            <TextField
              margin="dense"
              label="Category Description"
              fullWidth
              variant="outlined"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenDialog(false)} color="primary">
              Cancel
            </Button>
            <Button onClick={handleSubmit} color="primary">
              {currentCategory ? 'Update' : 'Add'}
            </Button>
          </DialogActions>
        </Dialog>
      </Container>
    </Box>
  );
};

export default AdminProducts;
