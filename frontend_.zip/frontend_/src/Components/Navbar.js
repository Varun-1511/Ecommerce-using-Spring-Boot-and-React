import React from 'react';
import { AppBar, Toolbar, Typography, Button, Box, TextField, IconButton } from '@mui/material';
import { Link, useNavigate } from 'react-router-dom';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import MenuIcon from '@mui/icons-material/Menu';

const Navbar = ({ onSearchFocus, onSearchChange }) => {
  const navigate = useNavigate();
  const isLoggedIn = !!localStorage.getItem('token');
  const username = localStorage.getItem('username');

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    localStorage.removeItem('userId'); // Clear user ID on logout if stored
    navigate('/login');
  };

  return (
    <AppBar position="static" sx={{ backgroundColor: '#2C3E50' }}>
      <Toolbar sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        {/* Logo */}
        <Typography
          variant="h6"
          component={Link}
          to="/"
          sx={{
            textDecoration: 'none',
            color: 'inherit',
            fontWeight: 'bold',
            fontFamily: 'Arial, sans-serif',
            '&:hover': {
              color: '#F1C40F', // Change logo color on hover
            },
          }}
        >
          QuitQ
        </Typography>

        {/* Search Bar */}
        <Box
          sx={{
            flexGrow: 1,
            mx: 2,
            maxWidth: { xs: '100%', sm: '50%' }, // Responsive size
          }}
        >
          <TextField
            fullWidth
            variant="outlined"
            placeholder="Browse Products..."
            size="small"
            sx={{
              backgroundColor: '#FFFFFF',
              borderRadius: '4px',
              input: { padding: '8px' },
              '& .MuiOutlinedInput-root:hover': {
                borderColor: '#3498DB', // Change border color on hover
              },
            }}
            onFocus={onSearchFocus}
            onChange={(e) => onSearchChange(e.target.value)} // Update search term
          />
        </Box>

        {/* Menu buttons */}
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
          }}
        >
          <IconButton
            color="inherit"
            component={Link}
            to="/cart"
            sx={{
              marginRight: 2,
              '&:hover': {
                color: '#E74C3C', // Change icon color on hover
              },
            }}
          >
            <ShoppingCartIcon />
          </IconButton>

          {isLoggedIn ? (
            <>
              <IconButton
                color="inherit"
                component={Link}
                to="/user-profile"
                sx={{
                  marginRight: 2,
                  '&:hover': {
                    color: '#1ABC9C', // Change profile icon color on hover
                  },
                }}
              >
                <AccountCircleIcon />
                <Typography
                  variant="body1"
                  sx={{
                    marginLeft: 1,
                    display: { xs: 'none', sm: 'block' },
                    '&:hover': {
                      color: '#1ABC9C', // Change text color on hover
                    },
                  }}
                >
                  {username}
                </Typography>
              </IconButton>
              <Button
                color="inherit"
                onClick={handleLogout}
                sx={{
                  marginRight: 2,
                  '&:hover': {
                    backgroundColor: '#E74C3C', // Change background on hover
                    color: 'white',
                  },
                }}
              >
                Logout
              </Button>
            </>
          ) : (
            <>
              <Button
                color="inherit"
                component={Link}
                to="/login"
                sx={{
                  marginRight: 2,
                  '&:hover': {
                    backgroundColor: '#3498DB', // Change background on hover
                    color: 'white',
                  },
                }}
              >
                Login
              </Button>
              <Button
                color="inherit"
                component={Link}
                to="/register"
                sx={{
                  marginRight: 2,
                  '&:hover': {
                    backgroundColor: '#9B59B6', // Change background on hover
                    color: 'white',
                  },
                }}
              >
                Register
              </Button>
              <Button
                color="inherit"
                component={Link}
                to="/seller-register"
                sx={{
                  backgroundColor: '#E74C3C',
                  '&:hover': {
                    backgroundColor: '#C0392B', // Darker red on hover
                  },
                  color: 'white',
                  borderRadius: '20px',
                  paddingX: 2,
                }}
              >
                Seller
              </Button>
            </>
          )}
        </Box>

        {/* Mobile view menu icon */}
        <IconButton
          sx={{
            display: { sm: 'none' },
            color: 'white',
            '&:hover': {
              color: '#F1C40F', // Change menu icon color on hover
            },
          }}
        >
          <MenuIcon />
        </IconButton>
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;
