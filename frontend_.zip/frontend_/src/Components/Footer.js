// src/Components/Footer.js
import React from 'react';
import { Link } from 'react-router-dom';
import '../Comp_css/Footer.css'; // Adjust your CSS import path as necessary

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-content">
        <p>&copy; {new Date().getFullYear()} QuitQ. All Rights Reserved.</p>
        <ul className="footer-links">
          <li><Link to="/about-us">About Us</Link></li>
          <li><Link to="/contact-us">Contact</Link></li>
          <li><Link to="/privacy-policy">Privacy Policy</Link></li>
          <li><Link to="/terms-of-service">Terms of Service</Link></li>
          <li><Link to="/admin-login">Admin Access</Link></li>
        </ul>
      </div>
    </footer>
  );
};

export default Footer;
