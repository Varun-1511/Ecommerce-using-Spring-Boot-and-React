import React from 'react';
import "../Comp_css/TermsOfService.css";

const TermsOfService = () => {
    return (
        <div className="terms-of-service-container">
            <h4>Terms of Service</h4>
            <p>By accessing and using QuitQ, you agree to comply with our Terms of Service. These terms govern your use of our website and services, outlining your rights and responsibilities. You must be at least 18 years old to create an account or make purchases. We reserve the right to modify these terms at any time, and it is your responsibility to stay informed of any changes. Violations of our terms may result in account suspension or termination. Please read our Terms of Service carefully to understand how we operate and ensure a safe environment for all users.

Feel free to modify these texts to better fit the voice and style of your application! If you need further assistance, just let me know!</p>
        </div>
    );
};

export default TermsOfService;
