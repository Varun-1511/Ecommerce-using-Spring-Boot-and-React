import React from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { Box, Typography, IconButton } from '@mui/material'; 
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import slideElectronic from '../images/offer2.png';
import slideFashion from '../images/sliderfashion.png';
import slideHome from '../images/sliderhome.png';
import offer5 from '../images/offer5.png';
import '../Comp_css/slider.css'; 

const OfferSlider = () => {
  const sliderSettings = {
    dots: true, 
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    customPaging: (i) => (
      <Box
        sx={{
          width: '12px',
          height: '12px',
          borderRadius: '50%',
          backgroundColor: '#ccc',
          margin: '0 5px',
          cursor: 'pointer',
        }}
      />
    ),
  };

  return (
    <Box sx={{ width: '100%', margin: '0 auto', marginBottom: '20px', position: 'relative' }}>
      <Slider {...sliderSettings}>
        <Box sx={{ width: '100%', height: '400px', position: 'relative' }}>
          <img src={"7.png"} alt="Offer 1" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          <Box className="overlay" sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
            color: 'white',
          }}>
            <Typography variant="h2" sx={{ fontSize: '28px', fontWeight: 'bold' }}>Exclusive Electronics Offer</Typography>
            <Typography variant="body1">Save up to 50% on select items!</Typography>
          </Box>
        </Box>
        <Box sx={{ width: '100%', height: '400px', position: 'relative' }}>
          <img src={slideFashion} alt="Offer 2" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          <Box className="overlay" sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
            color: 'white',
          }}>
            <Typography variant="h2" sx={{ fontSize: '28px', fontWeight: 'bold' }}>Fashion Deals Just for You</Typography>
            <Typography variant="body1">Trendy styles at unbeatable prices!</Typography>
          </Box>
        </Box>
        <Box sx={{ width: '100%', height: '400px', position: 'relative' }}>
          <img src={slideHome} alt="Offer 3" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          <Box className="overlay" sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
            color: 'white',
          }}>
            <Typography variant="h2" sx={{ fontSize: '28px', fontWeight: 'bold' }}>Home Essentials Sale</Typography>
            <Typography variant="body1">Refresh your space with our new arrivals!</Typography>
          </Box>
        </Box>
        <Box sx={{ width: '100%', height: '400px', position: 'relative' }}>
          <img src={offer5} alt="Offer 5" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          <Box className="overlay" sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
            color: 'white',
          }}>
            <Typography variant="h2" sx={{ fontSize: '28px', fontWeight: 'bold' }}>Special Offers on Mobiles</Typography>
            <Typography variant="body1">Don't miss out on these limited-time deals!</Typography>
          </Box>
        </Box>
      </Slider>

      {/* Custom Arrows */}
      <IconButton
        className="slick-arrow-left"
        onClick={() => document.querySelector('.slick-prev').click()}
        sx={{
          position: 'absolute',
          top: '50%',
          left: '10px',
          zIndex: 10,
          backgroundColor: 'white',
          '&:hover': { backgroundColor: '#f0f0f0' },
        }}
      >
        <ArrowBackIosIcon />
      </IconButton>
      <IconButton
        className="slick-arrow-right"
        onClick={() => document.querySelector('.slick-next').click()}
        sx={{
          position: 'absolute',
          top: '50%',
          right: '10px',
          zIndex: 10,
          backgroundColor: 'white',
          '&:hover': { backgroundColor: '#f0f0f0' },
        }}
      >
        <ArrowForwardIosIcon />
      </IconButton>
    </Box>
  );
};

export default OfferSlider;
