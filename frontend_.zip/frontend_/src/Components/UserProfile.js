import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Container, TextField, Button, Typography } from '@mui/material';
import '../Comp_css/UserProfile.css'; // Import the CSS file

const UserProfile = () => {
  const navigate = useNavigate();
  const [userData, setUserData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/login'); // Redirect to login if not authenticated
    } else {
      const uid = localStorage.getItem('uid'); // Assuming uid is stored in localStorage
      console.log('Retrieved User ID:', uid); // Debugging line

      // Check if uid is valid
      if (!uid) {
        alert('User ID not found. Please log in again.');
        navigate('/login');
        return;
      }

      fetch(`http://localhost:9090/auth/getUserById/${uid}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
        .then((response) => response.json())
        .then((data) => {
          setUserData((prev) => ({
            ...prev,
            username: data.username,
            email: data.email,
          }));
        })
        .catch((error) => {
          console.error('Error fetching user data:', error);
        });
    }
  }, [navigate]);

  const handleUpdate = async () => {
    const token = localStorage.getItem('token');
    const uid = localStorage.getItem('uid');

    if (!uid) {
      alert('User ID not found. Please log in again.');
      navigate('/login');
      return;
    }

    // Check if passwords match
    if (userData.password !== userData.confirmPassword) {
      alert("Passwords do not match!");
      return;
    }

    const response = await fetch(`http://localhost:9090/auth/updateUser/${uid}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        username: userData.username,
        email: userData.email,
        password: userData.password || undefined, // Only send password if provided
      }),
    });

    if (response.ok) {
      alert('Profile updated successfully');
      navigate('/'); // Optionally navigate to another page after update
    } else {
      alert('Failed to update profile');
    }
  };

  return (
    <Container className="container">
      <Typography variant="h4" className="title">Update Profile</Typography>
      <TextField
        label="Username"
        value={userData.username}
        onChange={(e) => setUserData({ ...userData, username: e.target.value })}
        fullWidth
        margin="normal"
        className="text-field"
      />
      <TextField
        label="Email"
        value={userData.email}
        onChange={(e) => setUserData({ ...userData, email: e.target.value })}
        fullWidth
        margin="normal"
        className="text-field"
      />
      <TextField
        label="Password"
        type="password"
        value={userData.password}
        onChange={(e) => setUserData({ ...userData, password: e.target.value })}
        fullWidth
        margin="normal"
        className="text-field"
      />
      <TextField
        label="Confirm Password"
        type="password"
        value={userData.confirmPassword}
        onChange={(e) => setUserData({ ...userData, confirmPassword: e.target.value })}
        fullWidth
        margin="normal"
        className="text-field"
      />
      <Button variant="contained" className="update-button" onClick={handleUpdate}>
        Update Profile
      </Button>
    </Container>
  );
};

export default UserProfile;
