import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { Box, Typography, Button, Rating } from '@mui/material';
import { useNavigate } from 'react-router-dom';




const predefinedRatings = {
    1: 4.1,
    2: 4.5,
    3: 3.8,
    4: 4.2,
    5: 4.0,
    11: 4.3,
    14:4.1,
    15:4.1,
    16:4.2,
};

const ProductCard = () => {
  const { id } = useParams(); 
  const [product, setProduct] = useState(null);
  const [error, setError] = useState(null);
  const [userRating, setUserRating] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProductDetails = async () => {
      try {
        const response = await axios.get(`http://localhost:9090/seller/products/getProductbyid?id=${id}`, {
          headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token')
          }
        });
        setProduct(response.data);
        console.log('Product details:', response.data);  
      } catch (error) {
        setError('Error fetching product details');
        console.error('Error fetching product details:', error.response ? error.response.data : error.message);
      }
    };

    fetchProductDetails();
  }, [id]);

  const handleBack = () => {
    navigate('/'); 
  };

  const handleRatingChange = (event, newValue) => {
    setUserRating(newValue);
    console.log(`User rated product ${id} with ${newValue} stars`);
  };

  if (error) {
    return <Typography variant="h6" color="error">{error}</Typography>;
  }

  if (!product) {
    return <Typography variant="h6">Loading...</Typography>;
  }

  return (
    <Box 
    sx={{ 
      padding: 2, 
      display: 'flex', 
      alignItems: 'flex-start', 
      gap: 4 
    }}
  >
      {/* Product Image */}
      <img 
        src={product.imageurl} alt={product.name} 
        style={{ width: '100%', maxWidth: '400px', height: 'auto' }} 
      />

      {/* Product Details */}
      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}> 
        <Typography variant="h4" gutterBottom>{product.name}</Typography>
        <Typography variant="h6">Category: {product.category}</Typography>
        <Typography variant="body1">Price: ₹{product.price}</Typography>
        <Typography variant="body1" paragraph>Description:{product.description}</Typography>

        {/* Predefined Rating */}
        <Typography variant="body1" paragraph>
          Product Rating: 
          <Rating
            name="read-only"
            value={predefinedRatings[product.id] || 0}  // Use the predefined rating
            readOnly
            precision={0.1}  // This allows for more precision, such as 4.1
          />
        </Typography>

        {/* User Rating Component */}
        <Typography component="legend">Rate this product:</Typography>
        <Rating 
          name="user-rating" 
          value={userRating} 
          onChange={handleRatingChange}
          precision={0.1} 
        />

        <Button variant="contained" color="primary" onClick={handleBack} sx={{ marginTop: 2 }}>
          Back to Products
        </Button>
      </Box>
    </Box>
  );
};

export default ProductCard;
