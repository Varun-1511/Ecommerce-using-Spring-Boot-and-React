import axios from "axios";
import { toast } from 'react-toastify'; // Import toast from react-toastify

const AddToCart = async (product) => {
    const token = localStorage.getItem('token'); 
    try {
        const response = await axios.post(
            'http://localhost:9090/users/cart/addToCart',
            null,
            {
                params: { productId: product.id, quantity: 1 }, // Passing params
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            }
        );
        if (response.status === 200) {
            toast.success(`${product.name} added to cart!`); // Show success toast
        }
    } catch (error) {
        console.error('Error adding to cart:', error);
        toast.error('Failed to add product to cart. Please check if you are logged in and try again.'); // Show error toast
    }
};

export default AddToCart;
