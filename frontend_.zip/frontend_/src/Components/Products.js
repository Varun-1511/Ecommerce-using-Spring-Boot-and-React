import React, { useEffect, useState } from 'react';
import { Button, TextField, Table, TableBody, TableCell, TableHead, TableRow, MenuItem, Select, InputLabel, FormControl, Card, CardContent, Typography, Collapse } from '@mui/material';
import axios from 'axios';

const Products = () => {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [newProduct, setNewProduct] = useState({ name: '', price: '', stock: '', imageurl: '', description: '', category: '' });
  const [productStock, setProductStock] = useState({});
  const [showAddProduct, setShowAddProduct] = useState(false); // State to manage card visibility

  useEffect(() => {
    fetchSellerProducts();
    fetchCategories();
  }, []);

  const fetchSellerProducts = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:9090/seller/products/getProducts', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setProducts(response.data);
    } catch (error) {
      console.error('Error fetching products', error);
    }
  };

  const fetchCategories = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:9090/admin/categories/getCategories', {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      setCategories(response.data);
    } catch (error) {
      console.error('Error fetching categories', error);
    }
  };

  const handleAddProduct = async () => {
    try {
      const token = localStorage.getItem('token');
      await axios.post('http://localhost:9090/seller/products/addProduct', newProduct, {
        headers: {
          Authorization: `Bearer ${token}`,
        }
      });
      fetchSellerProducts(); 
      setNewProduct({ name: '', price: '', stock: '', imageurl: '', description: '', category: '' });
      setShowAddProduct(false); 
    } catch (error) {
      console.error('Error adding product', error);
    }
  };

  const handleMarkOutOfStock = async (id) => {
    try {
      const token = localStorage.getItem('token');
      await axios.patch(`http://localhost:9090/seller/products/markOutOfStock/${id}`, {}, {
        headers: {
          Authorization: `Bearer ${token}`,
        }
      });
      fetchSellerProducts(); 
    } catch (error) {
      console.error('Error marking product out of stock', error);
    }
  };

  const handleUpdateStock = async (id) => {
    try {
      const token = localStorage.getItem('token');
      // Ensure the payload matches the backend's expected DTO structure
      const updatedStock = { stockNumber: productStock[id] };  // Use 'stockNumber' to match the backend
      await axios.put(`http://localhost:9090/seller/products/updateProduct/${id}`, updatedStock, {
        headers: {
          Authorization: `Bearer ${token}`,
        }
      });
      fetchSellerProducts(); // Fetch updated products after stock change
    } catch (error) {
      console.error('Error updating product stock', error);
    }
  };
  

  const handleStockChange = (id, value) => {
    setProductStock((prev) => ({
      ...prev,
      [id]: value
    }));
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', minHeight: '100vh' }}>
      {/* Add Product Button moved here */}
      <Button variant="contained" color="primary" onClick={() => setShowAddProduct(!showAddProduct)}>
        {showAddProduct ? 'Cancel' : 'Add Product'}
      </Button>

      {/* Collapse component for Add Product Card */}
      <Collapse in={showAddProduct}>
        <Card 
          style={{ 
            marginTop: '20px', 
            padding: '50px', 
            maxWidth: '500px',
            backgroundColor: '#f9f9f9', 
            boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
            borderRadius: '8px',
            transition: 'max-width 0.3s ease, box-shadow 0.3s ease',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center'
          }}
        >
          <CardContent>
            <Typography variant="h5" component="div" style={{ marginBottom: '15px' }}>
              Add New Product
            </Typography>
            <TextField 
              label="Name" 
              value={newProduct.name} 
              onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })} 
              fullWidth 
              margin="normal" 
            />
            <TextField 
              label="Price" 
              value={newProduct.price} 
              onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })} 
              fullWidth 
              margin="normal" 
            />
            <TextField 
              label="Stock" 
              value={newProduct.stock} 
              onChange={(e) => setNewProduct({ ...newProduct, stock: e.target.value })} 
              fullWidth 
              margin="normal" 
            />
            <TextField 
              label="Image URL" 
              value={newProduct.imageurl} 
              onChange={(e) => setNewProduct({ ...newProduct, imageurl: e.target.value })} 
              fullWidth 
              margin="normal" 
            />
            <TextField 
              label="Description" 
              value={newProduct.description} 
              onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })} 
              fullWidth 
              margin="normal" 
            />

            {/* Dropdown for Category */}
            <FormControl fullWidth margin="normal">
              <InputLabel>Category</InputLabel>
              <Select
                value={newProduct.category}
                onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
              >
                {categories.map((category) => (
                  <MenuItem key={category.id} value={category.name}>
                    {category.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <Button variant="contained" color="primary" onClick={handleAddProduct} style={{ marginTop: '15px' }}>
              Add Product
            </Button>
          </CardContent>
        </Card>
      </Collapse>

      <h2>Your Products</h2>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Name</TableCell>
            <TableCell>Price</TableCell>
            <TableCell>Stock</TableCell>
            <TableCell>Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {products.map(product => (
            <TableRow key={product.id}>
              <TableCell>{product.name}</TableCell>
              <TableCell>{product.price}</TableCell>
              <TableCell>
                <TextField
                  type="number"
                  value={productStock[product.id] || product.stock}
                  onChange={(e) => handleStockChange(product.id, e.target.value)}
                />
              </TableCell>
              <TableCell>
                <Button onClick={() => handleUpdateStock(product.id)}>Update Stock</Button>
                <Button onClick={() => handleMarkOutOfStock(product.id)}>Mark Out Of Stock</Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default Products;
