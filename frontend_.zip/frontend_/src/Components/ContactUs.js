import React from 'react';
import "../Comp_css/ContactUs.css";
const ContactUs = () => {
    return (
        <div className="contact-us-container">
            <h4>Contact Us</h4>
            <p>We value your feedback and are here to help you with any questions or concerns. If you need assistance, feel free to reach out to our customer support team at support@quitq.com. You can also contact us through our social media channels or visit our Help Center for FAQs. Your inquiries are important to us, and we aim to respond within 24 hours. For urgent matters, please call our support hotline at 1-800-QUITQ (1-800-784-827). Thank you for choosing QuitQ; we look forward to hearing from you!</p>
        </div>
    );
};

export default ContactUs;
