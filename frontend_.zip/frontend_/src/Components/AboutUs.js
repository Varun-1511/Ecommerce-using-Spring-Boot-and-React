import React from 'react';
import "../Comp_css/AboutUs.css";

const AboutUs = () => {
    return (
        <div className="about-us-container">
            <h4>About Us</h4>
            <p>At QuitQ, we are dedicated to providing a seamless e-commerce experience for our users. Our platform connects buyers and sellers in a user-friendly environment, where convenience meets quality. Founded on the principles of integrity and innovation, we strive to create a marketplace that prioritizes customer satisfaction. Our team is composed of industry professionals committed to enhancing your shopping experience. Whether you’re looking for unique products or seeking to sell your items, QuitQ is here to assist you. Join us as we revolutionize the way people buy and sell online!</p>
        </div>
    );
};

export default AboutUs;
