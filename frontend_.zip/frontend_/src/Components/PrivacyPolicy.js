import React from 'react';
import "../Comp_css/Privacy.css";

const PrivacyPolicy = () => {
    return (
        <div className="privacy-policy-container">
            <h4>Privacy Policy</h4>
            <p>At QuitQ, your privacy is our top priority. We are committed to safeguarding your personal information and using it responsibly. This Privacy Policy outlines how we collect, use, and protect your data when you use our services. We gather information to improve your experience, process transactions, and communicate effectively. We do not sell or share your information with third parties without your consent. By using our platform, you agree to our data practices as outlined in this policy. If you have any questions or concerns about your privacy, please reach out to our support team.</p>
        </div>
    );
};

export default PrivacyPolicy;
