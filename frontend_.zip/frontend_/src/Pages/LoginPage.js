// import React, { useState } from 'react';
// import { TextField, Button, Typography, Box, Snackbar } from '@mui/material';
// import { useNavigate } from 'react-router-dom';
// import axios from 'axios';
// // import '../Comp_css/LoginPage.css';

// const LoginPage = () => {
//   const [username, setUsername] = useState('');
//   const [password, setPassword] = useState('');
//   const [errorMessage, setErrorMessage] = useState('');
//   const [openSnackbar, setOpenSnackbar] = useState(false);
//   const navigate = useNavigate();

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const response = await axios.post('http://localhost:9090/auth/generateToken', { username, password });
//       const token = response.data;
//       localStorage.setItem('token', token);
//       localStorage.setItem('username', username);

//       navigate('/'); // Navigate to the home page on successful login
//     } catch (error) {
//       setErrorMessage('Invalid username or password.');
//       setOpenSnackbar(true);
//     }
//   };

//   const handleRegisterClick = () => {
//     navigate('/register'); // Navigate to the register page
//   };

//   const handleCloseSnackbar = () => {
//     setOpenSnackbar(false);
//   };

//   return (
//     <Box className="signin-container">
//       <Typography variant="h4">Login</Typography>
//       <form onSubmit={handleSubmit}>
//         <div className="input-container">
//           <TextField
//             label="Username"
//             variant="outlined"
//             fullWidth
//             margin="normal"
//             value={username}
//             onChange={(e) => setUsername(e.target.value)}
//             className="input-field"
//           />
//         </div>
//         <div className="input-container">
//           <TextField
//             label="Password"
//             type="password"
//             variant="outlined"
//             fullWidth
//             margin="normal"
//             value={password}
//             onChange={(e) => setPassword(e.target.value)}
//             className="input-field"
//           />
//         </div>
//         <Button variant="contained" type="submit" className="button">
//           Login
//         </Button>
//       </form>

//       <Typography variant="body2" className="register-link">
//         Don't have an account?{' '}
//         <span onClick={handleRegisterClick} style={{ cursor: 'pointer', textDecoration: 'underline', color: 'blue' }}>
//           Register here
//         </span>
//       </Typography>

//       <Snackbar
//         open={openSnackbar}
//         autoHideDuration={6000}
//         onClose={handleCloseSnackbar}
//         message={errorMessage}
//       />
//     </Box>
//   );
// };

// export default LoginPage;

import React, { useState } from 'react';
import { TextField, Button, Typography, Box, Snackbar, Grid, Paper, InputAdornment } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import AccountCircle from '@mui/icons-material/AccountCircle'; // Import account icon
import LockIcon from '@mui/icons-material/Lock'; // Import lock icon

const LoginPage = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:9090/auth/generateToken', { username, password });
      const token = response.data;
      localStorage.setItem('token', token);
      localStorage.setItem('username', username);
      navigate('/'); // Navigate to the home page on successful login
    } catch (error) {
      setErrorMessage('Invalid username or password.');
      setOpenSnackbar(true);
    }
  };

  const handleRegisterClick = () => {
    navigate('/register'); // Navigate to the register page
  };

  const handleCloseSnackbar = () => {
    setOpenSnackbar(false);
  };

  return (
    <Grid container>
      {/* Left Side with Image from URL */}
      <Grid item xs={12} sm={6} style={{ backgroundImage: `url(https://i.pinimg.com/originals/d7/64/c7/d764c70776b64e523cb4eea2f322db96.gif)`, backgroundSize: 'cover', backgroundPosition: 'center', height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center', borderRadius: '5%' }}>
        {/* Optional Overlay for Better Text Visibility */}
        <div style={{ backgroundColor: 'rgba(0, 0, 0, 0)', width: '100%', height: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', borderRadius: '5%' }}>
          <Typography
            variant="h2"
            style={{
              color: 'white',
              textAlign: 'center',
              padding: '20px',
              textShadow: '2px 2px 4px rgba(0, 0, 0, 0.7), 0 0 25px rgba(0, 0, 0, 0.6), 0 0 5px rgba(0, 0, 0, 0.9)',
              fontWeight: 'bold',
              fontSize: '2rem',
              letterSpacing: '0.1em',
            }}
          >
            Welcome Back!! to 'QuitQ'
          </Typography>
        </div>
      </Grid>

      {/* Right Side with Login Form */}
      <Grid item xs={12} sm={6} style={{ padding: '40px', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <Paper elevation={3} style={{ padding: '30px', borderRadius: '8px', width: '100%', maxWidth: '400px' }}>
        <Typography
  variant="h4"
  align="center"
  gutterBottom
  style={{
    backgroundColor: '#3f51b5',
    display: 'inline-block', 
    marginLeft:"35%",
    padding: '10px 20px', // Add padding for better visual effect
    color: 'white', // Change text color to white for contrast
    borderRadius: '15%', // Optional: Add border radius for rounded corners
  }}
>
  Login
</Typography>

          <form onSubmit={handleSubmit}>
            <div className="input-container">
              <TextField
                label="Username"
                variant="outlined"
                fullWidth
                margin="normal"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="input-field"
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <AccountCircle style={{ color: '#3f51b5' }} />
                    </InputAdornment>
                  ),
                }}
                sx={{
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderColor: '#3f51b5', // Custom border color
                    },
                    '&:hover fieldset': {
                      borderColor: '#f50057', // Hover color
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: '#f50057', // Focus color
                    },
                  },
                }}
              />
            </div>
            <div className="input-container">
              <TextField
                label="Password"
                type="password"
                variant="outlined"
                fullWidth
                margin="normal"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="input-field"
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <LockIcon style={{ color: '#3f51b5' }} />
                    </InputAdornment>
                  ),
                }}
                sx={{
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderColor: '#3f51b5', // Custom border color
                    },
                    '&:hover fieldset': {
                      borderColor: '#f50057', // Hover color
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: '#f50057', // Focus color
                    },
                  },
                }}
              />
            </div>
            <Button variant="contained" type="submit" className="button" fullWidth style={{ backgroundColor: '#3f51b5' }}>
              Login
            </Button>
          </form>

          <Typography variant="body2" align="center" className="register-link" style={{ marginTop: '15px' }}>
            Don't have an account?{' '}
            <span onClick={handleRegisterClick} style={{ cursor: 'pointer', textDecoration: 'underline', color: '#3f51b5' }}>
              Register here
            </span>
          </Typography>

          <Snackbar
            open={openSnackbar}
            autoHideDuration={6000}
            onClose={handleCloseSnackbar}
            message={errorMessage}
          />
        </Paper>
      </Grid>
    </Grid>
  );
};

export default LoginPage;
