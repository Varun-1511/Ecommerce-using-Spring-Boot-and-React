import React, { useState } from 'react';
import Modal from 'react-modal'; 
import '../Comp_css/PaymentPage.css';  
import placeOrder from '../Components/OrderCard'; 
import { ToastContainer, toast } from 'react-toastify'; 
import 'react-toastify/dist/ReactToastify.css'; 

Modal.setAppElement('#root');

const PaymentPage = () => {
    const [cardNumber, setCardNumber] = useState('');
    const [expiryDate, setExpiryDate] = useState('');
    const [cvv, setCvv] = useState('');
    const [cardName, setCardName] = useState('');
    const [modalIsOpen, setModalIsOpen] = useState(false); 

    const productId = 1;
    const quantity = 1; 

    const handlePaymentSubmit = (e) => {
        e.preventDefault();
        setModalIsOpen(true);
    };

    const confirmOrder = async () => {
        console.log('Processing Payment...');

        try {
            const orderDetails = await placeOrder(productId, quantity); 
            console.log("Order Details:", orderDetails);
            toast.success('Payment Successful! Order placed.'); 
        } catch (error) {
            console.error("Payment Error:", error.message); 
            toast.error('Payment failed: ' + error.message); 
        }

        setModalIsOpen(false);
    };

    const closeModal = () => {
        setModalIsOpen(false); 
    };

    return (
        <div className="payment-container">
            <h2>Payment Details</h2>
            <form className="payment-form" onSubmit={handlePaymentSubmit}>
                <label htmlFor="cardNumber">Card Number:</label>
                <input
                    type="text"
                    id="cardNumber"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    required
                />

                <label htmlFor="expiryDate">Expiry Date (MM/YY):</label>
                <input
                    type="text"
                    id="expiryDate"
                    value={expiryDate}
                    onChange={(e) => setExpiryDate(e.target.value)}
                    required
                />

                <label htmlFor="cvv">CVV:</label>
                <input
                    type="password"
                    id="cvv"
                    value={cvv}
                    onChange={(e) => setCvv(e.target.value)}
                    required
                />

                <label htmlFor="cardName">Cardholder Name:</label>
                <input
                    type="text"
                    id="cardName"
                    value={cardName}
                    onChange={(e) => setCardName(e.target.value)}
                    required
                />

                <button type="submit">Place Order</button>
            </form>

            <Modal
                isOpen={modalIsOpen}
                onRequestClose={closeModal}
                contentLabel="Confirm Order Modal"
                className="confirmation-modal"
                overlayClassName="modal-overlay"
            >
                <h2>Are you sure you want to place this order?</h2>
                <div className="modal-buttons">
                    <button onClick={confirmOrder} className="confirm-button">Yes, Place Order</button>
                    <button onClick={closeModal} className="cancel-button">Cancel</button>
                </div>
            </Modal>

            <ToastContainer />
        </div>
    );
};

export default PaymentPage;
