// import React, { useState } from 'react';
// import { useNavigate } from 'react-router-dom';
// import { Button, TextField, Typography, Box, MenuItem, Select, FormControl, InputLabel, Link } from '@mui/material'; // Import Link component
// import axios from 'axios';
// // import '../Comp_css/RegisterPage.css';

// const RegisterPage = () => {
//   const [name, setName] = useState('');
//   const [email, setEmail] = useState('');
//   const [password, setPassword] = useState('');
//   const [role, setRole] = useState('ROLE_USER');
//   const navigate = useNavigate();

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     const userData = { name, email, password, roles: role };

//     try {
//       await axios.post('http://localhost:9090/auth/addNewUser', userData);
//       navigate('/login');
//     } catch (error) {
//       console.error('Registration error:', error);
//     }
//   };

//   return (
//     <Box className="signin-container">
//       <Typography variant="h4">Register</Typography>
//       <form onSubmit={handleSubmit}>
//         <div className="input-container">
//           <TextField
//             label="Name"
//             variant="outlined"
//             fullWidth
//             margin="normal"
//             value={name}
//             onChange={(e) => setName(e.target.value)}
//           />
//         </div>
//         <div className="input-container">
//           <TextField
//             label="Email"
//             variant="outlined"
//             fullWidth
//             margin="normal"
//             value={email}
//             onChange={(e) => setEmail(e.target.value)}
//           />
//         </div>
//         <div className="input-container">
//           <TextField
//             label="Password"
//             type="password"
//             variant="outlined"
//             fullWidth
//             margin="normal"
//             value={password}
//             onChange={(e) => setPassword(e.target.value)}
//           />
//         </div>
//         <FormControl variant="outlined" fullWidth margin="normal">
//           <InputLabel>Role</InputLabel>
//           <Select
//             value={role}
//             onChange={(e) => setRole(e.target.value)}
//             label="Role"
//           >
//             <MenuItem value="ROLE_USER">User</MenuItem>
//             <MenuItem value="ROLE_ADMIN">Admin</MenuItem>
//             <MenuItem value="ROLE_SELLER">Seller</MenuItem>
//           </Select>
//         </FormControl>
//         <Button variant="contained" type="submit" className="button">
//           Register
//         </Button>
//       </form>

//       <Typography variant="body2" className="login-link">
//         Already have an account?{' '}
//         <Link href="/login" underline="hover">
//           Login here
//         </Link>
//       </Typography>
//     </Box>
//   );
// };

// export default RegisterPage;



import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Button,
  TextField,
  Typography,
  Box,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
  Link,
  Grid,
  Paper,
} from '@mui/material'; 
import axios from 'axios';

const RegisterPage = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('ROLE_USER');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const userData = { name, email, password, roles: role };

    try {
      await axios.post('http://localhost:9090/auth/addNewUser', userData);
      navigate('/login');
    } catch (error) {
      console.error('Registration error:', error);
    }
  };

  return (
    <Grid container style={{ height: '100vh' }}>
      {/* Left Side - Form Container */}
      <Grid item xs={12} sm={6} style={{ padding: '40px', backgroundColor: '#ffff' }}>
        <Paper elevation={3} style={{ padding: '30px', borderRadius: '8px', maxWidth: '400px', margin: 'auto' }}>
          <Typography variant="h4" align="center" style={{ marginBottom: '20px' }}>
            Register
          </Typography>
          <form onSubmit={handleSubmit}>
            <div className="input-container">
              <TextField
                label="Name"
                variant="outlined"
                fullWidth
                margin="normal"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div className="input-container">
              <TextField
                label="Email"
                variant="outlined"
                fullWidth
                margin="normal"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="input-container">
              <TextField
                label="Password"
                type="password"
                variant="outlined"
                fullWidth
                margin="normal"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <FormControl variant="outlined" fullWidth margin="normal">
              <InputLabel>Role</InputLabel>
              <Select
                value={role}
                onChange={(e) => setRole(e.target.value)}
                label="Role"
              >
                <MenuItem value="ROLE_USER">User</MenuItem>
                
              </Select>
            </FormControl>
            <Button variant="contained" type="submit" fullWidth style={{ backgroundColor: '#d32f2f', color: 'white', marginTop: '20px' }}>
              Register
            </Button>
          </form>

          <Typography variant="body2" align="center" style={{ marginTop: '15px' }}>
            Already have an account?{' '}
            <Link href="/login" underline="hover" style={{ color: '#d32f2f' }}>
              Login here
            </Link>
          </Typography>
        </Paper>
      </Grid>

      {/* Right Side - Background Image */}
      <Grid
        item
        xs={12}
        sm={6}
        style={{
          backgroundImage: `url('https://i.pinimg.com/originals/d7/57/3b/d7573b3e236d935c3f87f3d5668a4695.gif')`, // Add your image URL here
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          height:'100%'
        }}
      />
    </Grid>
  );
};

export default RegisterPage;
