import { useState } from "react";
import { TextField, Button, Box, Typography, Paper, InputAdornment } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { Person, Lock } from "@mui/icons-material";
import axios from "axios";
import { toast } from "react-toastify";

const SellerLogin = () => {
  const [credentials, setCredentials] = useState({
    username: "",
    password: "",
  });
  const navigate = useNavigate();

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:9090/auth/generateToken", credentials);
      if (response.data) {
        localStorage.setItem("token", response.data); // Storing JWT
        
        toast.success("Login Successfull!");
        navigate("/seller-dashboard");
      }
    } catch (error) {
      console.error("Login failed", error);
      toast.error("Invalid credentials");
    }
  };

  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh',
        backgroundColor: '#f5f5f5',
        backgroundImage: 'url("8.png")', // Add your background image path
        backgroundSize: 'cover',
      }}
    >
      <Paper
        elevation={8}
        sx={{
          padding: 4,
          borderRadius: 3,
          maxWidth: 472,
          width: '100%',
          boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
          backgroundColor: '#ffffff',
        }}
      >
        <Typography variant="h4" gutterBottom align="center" sx={{ fontWeight: 'bold', color: '#323232' }}>
          Seller Login
        </Typography>
        <form onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label="Username"
            name="username"
            value={credentials.username}
            onChange={handleChange}
            margin="normal"
            variant="outlined"
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Person />
                </InputAdornment>
              ),
              sx: {
                borderRadius: '8px',
              },
            }}
          />
          <TextField
            fullWidth
            label="Password"
            type="password"
            name="password"
            value={credentials.password}
            onChange={handleChange}
            margin="normal"
            variant="outlined"
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Lock />
                </InputAdornment>
              ),
              sx: {
                borderRadius: '8px',
              },
            }}
          />
          <Button
            type="submit"
            variant="contained"
            color="primary"
            fullWidth
            sx={{
              marginTop: 2,
              paddingY: 1.5,
              borderRadius: '8px',
              backgroundColor: '#323232',
              boxShadow: '0 3px 5px rgba(0, 0, 0, 0.3)',
              '&:hover': {
                backgroundColor: '#adadad',
                boxShadow: '0 5px 10px rgba(0, 0, 0, 0.5)',
              },
            }}
          >
            Login
          </Button>
        </form>
      </Paper>
    </Box>
  );
};

export default SellerLogin;
