import React, { useState } from 'react';
import { AppBar, Toolbar, Button, Box, Typography, Container } from '@mui/material';
import Products from '../Components/Products';
import Orders from '../Pages/Orders';  
import { useNavigate } from 'react-router-dom';

const SellerDashboard = () => {
  const [activeSection, setActiveSection] = useState('products');
  const navigate = useNavigate();

  const handleSectionChange = (section) => {
    setActiveSection(section);
  };

  const handleLogout = () => {
    
    localStorage.removeItem('token'); 
    navigate('/'); 
  };

  return (
    <>
      {/* Navbar */}
      <AppBar position="static" sx={{ backgroundColor: '#2E3B55' }}>
        <Toolbar>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            Seller Dashboard
          </Typography>

          {/* Products and Orders Section Buttons */}
          <Button
            color="inherit"
            variant={activeSection === 'products' ? 'contained' : 'outlined'}
            onClick={() => handleSectionChange('products')}
            sx={{ mx: 1, backgroundColor: activeSection === 'products' ? '#FF6F61' : '', color: activeSection === 'products' ? '#fff' : '' }}
          >
            Products
          </Button>
          <Button
            color="inherit"
            variant={activeSection === 'orders' ? 'contained' : 'outlined'}
            onClick={() => handleSectionChange('orders')}
            sx={{ mx: 1, backgroundColor: activeSection === 'orders' ? '#FF6F61' : '', color: activeSection === 'orders' ? '#fff' : '' }}
          >
            Orders
          </Button>

          {/* Logout Button */}
          <Button
            color="secondary"
            variant="contained"
            onClick={handleLogout}
            sx={{ ml: 2, backgroundColor: '#FF6F61', color: '#fff' }}
          >
            Logout
          </Button>
        </Toolbar>
      </AppBar>

      {/* Main Content */}
      <Container sx={{ mt: 5 }}>
        <Box>
          {activeSection === 'products' && <Products />} {/* Show Products */}
          {activeSection === 'orders' && <Orders />}     {/* Show Orders */}
        </Box>
      </Container>
    </>
  );
};

export default SellerDashboard;
