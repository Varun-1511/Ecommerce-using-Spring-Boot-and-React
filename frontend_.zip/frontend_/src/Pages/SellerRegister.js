// import { useState } from "react";
// import { TextField, Button, Box, Typography } from "@mui/material";
// import { useNavigate } from "react-router-dom";
// import axios from "axios";

// const SellerRegister = () => {
//   const [sellerData, setSellerData] = useState({
//     name: "",
//     email: "",
//     password: "",
//     roles: "ROLE_SELLER",
//   });
//   const navigate = useNavigate();

//   const handleChange = (e) => {
//     setSellerData({ ...sellerData, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const response = await axios.post("http://localhost:9090/auth/addNewUser", sellerData);
//       if (response.status === 200) {
//         alert("Registration successful! Redirecting to login page...");
//         navigate("/seller-login");
//       }
//     } catch (error) {
//       console.error("Registration failed", error);
//       alert("Error registering seller");
//     }
//   };

//   return (
//     <Box sx={{ maxWidth: 400, mx: "auto", mt: 5 }}>
//       <Typography variant="h4" gutterBottom>
//         Seller Registration
//       </Typography>
//       <form onSubmit={handleSubmit}>
//         <TextField
//           fullWidth
//           label="Name"
//           name="name"
//           value={sellerData.name}
//           onChange={handleChange}
//           margin="normal"
//         />
//         <TextField
//           fullWidth
//           label="Email"
//           name="email"
//           value={sellerData.email}
//           onChange={handleChange}
//           margin="normal"
//         />
//         <TextField
//           fullWidth
//           label="Password"
//           type="password"
//           name="password"
//           value={sellerData.password}
//           onChange={handleChange}
//           margin="normal"
//         />
//         <Button type="submit" variant="contained" color="primary" fullWidth>
//           Register
//         </Button>
//       </form>
//       <Button onClick={() => navigate("/seller-login")} sx={{ mt: 2 }}>
//         Already have an account? Login here
//       </Button>
//     </Box>
//   );
// };

// export default SellerRegister;

import { useState } from "react";
import { TextField, Button, Box, Typography, Paper, InputAdornment } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { Person, Email, Lock } from "@mui/icons-material";
import axios from "axios";
import { toast } from "react-toastify";

const SellerRegister = () => {
  const [sellerData, setSellerData] = useState({
    name: "",
    email: "",
    password: "",
    roles: "ROLE_SELLER",
  });
  const navigate = useNavigate();

  const handleChange = (e) => {
    setSellerData({ ...sellerData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:9090/auth/addNewUser", sellerData);
    //   if (response.status === 200) {
    //      alert("Registration successful! Redirecting to login page...");
    //     navigate("/seller-login");
    //   }
    // } catch (error) {
    //   console.error("Registration failed", error);
    //   alert("Error registering seller");
    // }
    if (response.status === 200) {
      toast.success(`Registered Successfully!`); // Show success toast
      navigate("/seller-login")
  }
} catch (error) {
  console.error('Error! while registering', error);
  toast.error('Error! Check the Inputs!!'); // Show error toast
}

  };

  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh',
        backgroundImage: 'url(https://plus.unsplash.com/premium_photo-1681488350342-19084ba8e224?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8ZSUyMGNvbW1lcmNlfGVufDB8fDB8fHww)', // Replace with actual image URL
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      <Paper
        elevation={6}
        sx={{
          padding: 5,
          borderRadius: 3,
          maxWidth: 500,
          width: '100%',
          backgroundColor: 'rgba(255, 255, 255, 0.85)', // semi-transparent background
        }}
      >
        <Typography
          variant="h4"
          gutterBottom
          align="center"
          sx={{ fontWeight: 'bold', color: '#545454' }}
        >
          Seller Registration
        </Typography>
        <form onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label="Name"
            name="name"
            value={sellerData.name}
            onChange={handleChange}
            margin="normal"
            variant="outlined"
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Person sx={{ color: '#ff914d' }} />
                </InputAdornment>
              ),
              sx: {
                borderRadius: '8px',
              },
            }}
          />
          <TextField
            fullWidth
            label="Email"
            name="email"
            value={sellerData.email}
            onChange={handleChange}
            margin="normal"
            variant="outlined"
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Email sx={{ color: '#ff914d' }} />
                </InputAdornment>
              ),
              sx: {
                borderRadius: '8px',
              },
            }}
          />
          <TextField
            fullWidth
            label="Password"
            type="password"
            name="password"
            value={sellerData.password}
            onChange={handleChange}
            margin="normal"
            variant="outlined"
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Lock sx={{ color: '#ff914d' }} />
                </InputAdornment>
              ),
              sx: {
                borderRadius: '8px',
              },
            }}
          />
          <Button
            type="submit"
            variant="contained"
            color="primary"
            fullWidth
            sx={{
              marginTop: 3,
              paddingY: 1.5,
              borderRadius: '8px',
              backgroundColor: '#5E5D62',
              boxShadow: '0 4px 6px rgba(0, 0, 0, 0.2)',
              '&:hover': {
                backgroundColor: '#3f51b5',
              },
            }}
          >
            Register
          </Button>
        </form>
        <Button
          onClick={() => navigate("/seller-login")}
          fullWidth
          sx={{
            marginTop: 2,
            color: '#3f51b5',
            '&:hover': {
              textDecoration: 'underline',
              color: '#ff914d',
            },
          }}
        >
          Already have an account? Login here
        </Button>
      </Paper>
    </Box>
  );
};

export default SellerRegister;
