import React, { useEffect, useState } from 'react';
import { Container, Grid, Paper, Typography, Box } from '@mui/material';
import Sidebar from '../Components/Sidebar';
import PeopleIcon from '@mui/icons-material/People';
import CategoryIcon from '@mui/icons-material/Category';

const AdminDashboard = () => {
  const [totalUsers, setTotalUsers] = useState(0);
  const [totalCategories, setTotalCategories] = useState(0);

  useEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem('adminToken');

      if (token) {
        try {
          // Fetch total users
          const usersResponse = await fetch('http://localhost:9090/auth/getAllUsers', {
            headers: {
              Authorization: `Bearer ${token}`, // Fixing token syntax
            },
          });

          if (usersResponse.ok) {
            const users = await usersResponse.json();
            setTotalUsers(users.length);
          } else {
            console.error('Error fetching users:', usersResponse.statusText);
          }

          // Fetch total categories
          const categoriesResponse = await fetch('http://localhost:9090/admin/categories/getCategories', {
            headers: {
              Authorization: `Bearer ${token}`, // Fixing token syntax
            },
          });

          if (categoriesResponse.ok) {
            const categories = await categoriesResponse.json();
            setTotalCategories(categories.length);
          } else {
            console.error('Error fetching categories:', categoriesResponse.statusText);
          }
        } catch (error) {
          console.error('Error fetching data:', error);
        }
      } else {
        console.error('Token not found');
      }
    };

    fetchData();
  }, []);

  return (
    <Box sx={{ display: 'flex', backgroundColor: '#f4f6f8', minHeight: '100vh' }}>
      <Sidebar />
      <Container sx={{ marginLeft: '240px', padding: 4 }}>
        <Typography variant="h4" sx={{ mb: 3, color: '#2c3e50', fontWeight: 'bold' }}>
          Admin Dashboard
        </Typography>

        <Grid container spacing={3}>
          {/* Total Users Card */}
          <Grid item xs={12} md={6} lg={4}>
            <Paper
              sx={{
                padding: 3,
                display: 'flex',
                alignItems: 'center',
                backgroundColor: '#2c3e50',
                color: '#fff',
              }}
            >
              <PeopleIcon sx={{ fontSize: 50, mr: 2 }} />
              <Box>
                <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                  Total Users
                </Typography>
                <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
                  {totalUsers}
                </Typography>
              </Box>
            </Paper>
          </Grid>

          {/* Total Categories Card */}
          <Grid item xs={12} md={6} lg={4}>
            <Paper
              sx={{
                padding: 3,
                display: 'flex',
                alignItems: 'center',
                backgroundColor: '#34495e',
                color: '#fff',
              }}
            >
              <CategoryIcon sx={{ fontSize: 50, mr: 2 }} />
              <Box>
                <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                  Total Categories
                </Typography>
                <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
                  {totalCategories}
                </Typography>
              </Box>
            </Paper>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default AdminDashboard;
