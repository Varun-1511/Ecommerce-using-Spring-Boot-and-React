// import React, { useState } from 'react';
// import { useNavigate } from 'react-router-dom';
// import {
//   TextField,
//   Button,
//   Paper,
//   Typography,
//   Container,
//   Box,
// } from '@mui/material';

// const AdminLogin = () => {
//   const [adminUsername, setAdminUsername] = useState('');
//   const [password, setPassword] = useState('');
//   const navigate = useNavigate();

//   const handleLogin = async (e) => {
//     e.preventDefault();
//     const response = await fetch('http://localhost:9090/auth/generateToken', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//       },
//       body: JSON.stringify({ username: adminUsername, password }),
//     });

//     if (response.ok) {
//       const data = await response.text();
//       localStorage.setItem('adminToken', data);
//       navigate('/admin-dashboard');
//     } else {
//       alert('Login failed. Please check your credentials.');
//     }
//   };

//   return (
//     <Box
//       sx={{
//         height: '100vh',
//         backgroundImage: 'url(https://plus.unsplash.com/premium_photo-1681488262364-8aeb1b6aac56?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8ZWNvbW1lcmNlfGVufDB8MHwwfHx8MA%3D%3D)', // New background image
//         backgroundSize: 'cover',
//         display: 'flex',
//         alignItems: 'center',
//         justifyContent: 'center',
//       }}
//     >
//       <Container maxWidth="sm">
//         <Paper
//           sx={{
//             padding: '40px',
//             backgroundColor: 'rgba(255, 255, 255, 0.8)',
//             boxShadow: 3, // Increased shadow for depth
//             borderRadius: 4, // Added border radius for softer corners
//           }}
//         >
//           <Typography variant="h4" component="h2" gutterBottom>
//             Admin Login
//           </Typography>
//           <form onSubmit={handleLogin}>
//             <TextField
//               label="Username"
//               variant="outlined"
//               fullWidth
//               sx={{ marginBottom: '20px' }}
//               value={adminUsername}
//               onChange={(e) => setAdminUsername(e.target.value)}
//               required
//             />
//             <TextField
//               label="Password"
//               type="password"
//               variant="outlined"
//               fullWidth
//               sx={{ marginBottom: '20px' }}
//               value={password}
//               onChange={(e) => setPassword(e.target.value)}
//               required
//             />
//             <Button
//               variant="contained"
//               color="primary"
//               fullWidth
//               type="submit"
//               sx={{ marginTop: '20px' }}
//             >
//               Login
//             </Button>
//           </form>
//         </Paper>
//       </Container>
//     </Box>
//   );
// };

// export default AdminLogin;

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  TextField,
  Button,
  Paper,
  Typography,
  Container,
  Box,
  IconButton,
  InputAdornment,
} from '@mui/material';
import { AccountCircle, Lock } from '@mui/icons-material';

const AdminLogin = () => {
  const [adminUsername, setAdminUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    const response = await fetch('http://localhost:9090/auth/generateToken', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username: adminUsername, password }),
    });

    if (response.ok) {
      const data = await response.text();
      localStorage.setItem('adminToken', data);
      navigate('/admin-dashboard');
    } else {
      alert('Login failed. Please check your credentials.');
    }
  };

  return (
    <Box
      sx={{
        height: '100vh',
        backgroundImage: 'url(9.png)', // New background image
        backgroundSize: 'cover',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Container maxWidth="sm">
        <Paper
          sx={{
            padding: '40px',
            backgroundColor: 'rgba(255, 255, 255, 0.8)',
            boxShadow: 3, // Increased shadow for depth
            borderRadius: 4, // Added border radius for softer corners
          }}
        >
          <Typography variant="h4" component="h2" gutterBottom>
            Admin Login
          </Typography>
          <form onSubmit={handleLogin}>
            <TextField
              label="Username"
              variant="outlined"
              fullWidth
              sx={{ marginBottom: '20px' }}
              value={adminUsername}
              onChange={(e) => setAdminUsername(e.target.value)}
              required
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <AccountCircle />
                  </InputAdornment>
                ),
              }}
            />
            <TextField
              label="Password"
              type="password"
              variant="outlined"
              fullWidth
              sx={{ marginBottom: '20px' }}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Lock />
                  </InputAdornment>
                ),
              }}
            />
            <Button
              variant="contained"
              color="primary"
              fullWidth
              type="submit"
              sx={{ marginTop: '20px' }}
            >
              Login
            </Button>
          </form>
        </Paper>
      </Container>
    </Box>
  );
};

export default AdminLogin;
