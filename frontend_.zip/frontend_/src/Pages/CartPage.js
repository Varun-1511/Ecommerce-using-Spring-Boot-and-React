import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../Comp_css/CartPage.css';
import roundNeckTshirt from "../images/fashion_round_neck_tshirt.avif";
import iphone from "../images/iphone15.png";
import cropTop from "../images/crop.jpg";
import tv from "../images/electronics_tv.jpg";
import tshirt from "../images/fashion_tshirt.jpg";
import sofa from "../images/home_sofa.jpg";
import kids5 from "../images/kids5.jpeg"
import { useNavigate } from 'react-router-dom';

const productImages = {
    1: roundNeckTshirt,
    2: iphone,
    3: cropTop,
    4: tv,
    5: tshirt,
    11: sofa,
    14: kids5,
};

const CartPage = () => {
    const [cartItems, setCartItems] = useState([]); 
    const [cartTotal, setCartTotal] = useState(0);   
    const [loading, setLoading] = useState(true);   
    const [error, setError] = useState(null);  
    const navigate = useNavigate();      

    useEffect(() => {
        fetchCartItems();
    }, []);

    const fetchCartItems = async () => {
        try {
            const response = await axios.get('http://localhost:9090/users/cart/items', {
                headers: {
                    'Authorization': 'Bearer ' + localStorage.getItem('token')  
                }
            });
            setCartItems(response.data); 
            calculateTotal(response.data);  
            setLoading(false);
        } catch (err) {
            console.error("Error fetching cart items: ", err);
            setError("Failed to load cart items");
            setLoading(false);
        }
    };

    const calculateTotal = (items) => {
        const total = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        setCartTotal(total);
    };

    const removeFromCart = async (productId) => {
        try {
            const response = await axios.delete('http://localhost:9090/users/cart/removeItem', {
                params: { productId },
                headers: {
                    'Authorization': 'Bearer ' + localStorage.getItem('token')
                }
            });
    
            console.log("Response:", response.data); 
    
            if (response.data.cartItems) {
                setCartItems(response.data.cartItems);
                calculateTotal(response.data.cartItems);
            } else {
                console.error("Unexpected response structure:", response.data);
                setError("Failed to update cart items");
            }
        } catch (err) {
            console.error("Error removing from cart: ", err);
            setError("Failed to remove item from cart");
        }
    };
    

    const updateQuantity = async (productId, quantity) => {
        if (quantity < 1) return; 
        try {
            await axios.put('http://localhost:9090/users/cart/updateCart', null, {
                params: { productId, quantity },
                headers: {
                    'Authorization': 'Bearer ' + localStorage.getItem('token')
                }
            });

            fetchCartItems();
        } catch (err) {
            console.error("Error updating cart: ", err.response ? err.response.data : err); 
            setError("Failed to update cart: " + (err.response ? err.response.data.message : err.message)); 
        }
    };

    const handleCheckout = () => {
        navigate('/address');
    };

    if (loading) {
        return <div className="loading">Loading...</div>;
    }

    if (error) {
        return <div className="error">Error: {error}</div>;
    }

    return (
        <div className="cart-container">
            <h1>Your Cart</h1>
            {cartItems.length === 0 ? (
                <div>
                    <p>Your cart is empty</p>
                    <p>Shop with QuitQ!</p> 
                </div>
            ) : (
                <div>
                    {cartItems.map((item) => (
                        <div className="cart-item" key={item.productId} style={{ display: 'flex', alignItems: 'center' }}>
                           
                            <img 
                                src={productImages[item.productId]} 
                                alt={item.productName} 
                                style={{ width: '100px', height: '100px', marginRight: '10px' }} 
                            />
                            <div style={{ flexGrow: 1 }}>
                                <p>{item.productName}</p>
                                <p>Price: ${item.price.toFixed(2)}</p>
                                <p>Quantity: {item.quantity}</p>
                            </div>
                            <div>
                                <button onClick={() => updateQuantity(item.productId, item.quantity + 1)}>+</button>
                                <button onClick={() => updateQuantity(item.productId, item.quantity - 1)}>-</button>
                                <button className="remove" onClick={() => removeFromCart(item.productId)}>Remove</button>
                            </div>
                        </div>
                    ))}
                    <div className="total-container">
                        <h2 className="cart-total">Total: ${cartTotal.toFixed(2)}</h2>
                    </div>
                    <div className="checkout-container">
                        <button className="checkout-button" onClick={handleCheckout}>Proceed to Checkout</button>
                    </div>
                </div>
            )}
        </div>
    );
    };

export default CartPage;
