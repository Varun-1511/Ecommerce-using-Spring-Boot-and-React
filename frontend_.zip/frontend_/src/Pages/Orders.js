import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Container, List, ListItem, ListItemText, Typography, Tabs, Tab } from '@mui/material';

const Orders = () => {
    const [orders, setOrders] = useState([]);
    const [orderHistory, setOrderHistory] = useState([]);
    const [tabValue, setTabValue] = useState(0);

    // Fetch current orders
    const fetchOrders = async () => {
        try {
            const token = localStorage.getItem('token'); // Get the token from localStorage

            const response = await axios.get('http://localhost:9090/seller/orders/viewOrders', {
                headers: {
                    Authorization: `Bearer ${token}`, // Set the Authorization header
                },
            });

            setOrders(response.data);
        } catch (error) {
            console.error('There was an error fetching the orders!', error);
        }
    };

    // Fetch order history
    const fetchOrderHistory = async () => {
        try {
            const token = localStorage.getItem('token'); // Get the token from localStorage

            const response = await axios.get('http://localhost:9090/seller/orders/viewOrderHistory', {
                headers: {
                    Authorization: `Bearer ${token}`, // Set the Authorization header
                },
            });

            setOrderHistory(response.data);
        } catch (error) {
            console.error('There was an error fetching the order history!', error);
        }
    };

    // Fetch orders and order history on component mount
    useEffect(() => {
        fetchOrders();
        fetchOrderHistory();
    }, []);

    const handleTabChange = (event, newValue) => {
        setTabValue(newValue);
    };

    return (
        <Container>
            <Typography variant="h4" gutterBottom>
                Online Shopping - Seller Portal
            </Typography>

            {/* Tabs to switch between current orders and order history */}
            <Tabs value={tabValue} onChange={handleTabChange}>
                <Tab label="Current Orders" />
                <Tab label="Order History" />
            </Tabs>

            {/* Display current orders */}
            {tabValue === 0 && (
                <List>
                    {orders.map((order) => (
                        <ListItem key={order.id}>
                            <ListItemText 
                                primary={`Order ID: ${order.id}, Status: ${order.status}, Total Amount: ${order.totalAmount}`} 
                                secondary={`Seller: ${order.seller.name}, User: ${order.user.name}, Items: ${order.items.map(item => item.productName).join(', ')}`} 
                            />
                        </ListItem>
                    ))}
                </List>
            )}

            {/* Display order history */}
            {tabValue === 1 && (
                <List>
                    {orderHistory.map((order) => (
                        <ListItem key={order.id}>
                            <ListItemText 
                                primary={`Order ID: ${order.id}, Status: ${order.status}, Total Amount: ${order.totalAmount}`} 
                                secondary={`Seller: ${order.seller.name}, User: ${order.user.name}, Items: ${order.items.map(item => item.productName).join(', ')}`} 
                            />
                        </ListItem>
                    ))}
                </List>
            )}
        </Container>
    );
};

export default Orders;
