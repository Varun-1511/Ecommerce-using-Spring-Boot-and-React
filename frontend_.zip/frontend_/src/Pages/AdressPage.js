import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, TextField, Button, Typography, Paper, Container } from '@mui/material';

const AddressPage = () => {
    const [address, setAddress] = useState('');
    const [city, setCity] = useState('');
    const [postalCode, setPostalCode] = useState('');
    const [country, setCountry] = useState('');
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        // Store address in localStorage or pass it via state
        localStorage.setItem('shippingAddress', JSON.stringify({
            address,
            city,
            postalCode,
            country
        }));
        // Navigate to the payment page
        navigate('/payment');
    };

    return (
        <Container maxWidth="sm">
            <Paper elevation={4} sx={{ padding: 4, borderRadius: 3, backgroundColor: '#f5f5f5' }}>
                <Typography variant="h4" gutterBottom align="center">
                    Enter Shipping Address
                </Typography>
                <form onSubmit={handleSubmit}>
                    <Box sx={{ marginBottom: 2 }}>
                        <TextField
                            label="Address"
                            value={address}
                            onChange={(e) => setAddress(e.target.value)}
                            fullWidth
                            required
                            variant="outlined"
                            sx={{ borderRadius: '8px' }}
                        />
                    </Box>
                    <Box sx={{ marginBottom: 2 }}>
                        <TextField
                            label="City"
                            value={city}
                            onChange={(e) => setCity(e.target.value)}
                            fullWidth
                            required
                            variant="outlined"
                            sx={{ borderRadius: '8px' }}
                        />
                    </Box>
                    <Box sx={{ marginBottom: 2 }}>
                        <TextField
                            label="Postal Code"
                            value={postalCode}
                            onChange={(e) => setPostalCode(e.target.value)}
                            fullWidth
                            required
                            variant="outlined"
                            sx={{ borderRadius: '8px' }}
                        />
                    </Box>
                    <Box sx={{ marginBottom: 2 }}>
                        <TextField
                            label="Country"
                            value={country}
                            onChange={(e) => setCountry(e.target.value)}
                            fullWidth
                            required
                            variant="outlined"
                            sx={{ borderRadius: '8px' }}
                        />
                    </Box>
                    <Button
                        type="submit"
                        variant="contained"
                        color="primary"
                        fullWidth
                        sx={{
                            marginTop: 2,
                            paddingY: 1.5,
                            borderRadius: '8px',
                            backgroundColor: '#323232',
                            '&:hover': {
                                backgroundColor: '#adadad',
                            },
                        }}
                    >
                        Next
                    </Button>
                </form>
            </Paper>
        </Container>
    );
};

export default AddressPage;
