/*import React, { useEffect, useState } from 'react';
import { Box, Typography, FormControl, InputLabel, Select, MenuItem, TextField, Button } from '@mui/material';
import axios from 'axios';
import '../Comp_css/HomePage.css'; 
import '../Comp_css/slider.css'; 
import OfferSlider from '../Components/OfferSlider';
import { useNavigate } from 'react-router-dom';
import Navbar from '../Components/Navbar'; 

// Importing Category Images
import Home_essentials from "../images/Home_essentials.avif";
import kids_fashion from "../images/kids_fashion.avif";
import Kitchen_must_haves from "../images/Kitchen_must_haves.avif";
import Laptops_and_Tablets from "../images/Laptops_and_Tablets.avif";
import men_fashion from "../images/men_fashion.avif";
import Smart_Televisions from "../images/Smart_Televisions.avif";

// Importing Product Images
import roundNeckTshirt from "../images/fashion_round_neck_tshirt.avif";
import iphone from "../images/iphone15.png";
import cropTop from "../images/crop.jpg";
import tv from "../images/electronics_tv.jpg";
import tshirt from "../images/fashion_tshirt.jpg";
import sofa from "../images/home_sofa.jpg";
import AddToCart from '../Components/AddToCart';
import { ToastContainer } from 'react-toastify';

const HomePage = () => {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [filterCategory, setFilterCategory] = useState('');
  const [sortOrder, setSortOrder] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const navigate = useNavigate(); 

  const productImages = {
    1: roundNeckTshirt,
    2: iphone,
    3: cropTop,
    4: tv,
    5: tshirt,
    11: sofa,
  };

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      setIsLoggedIn(true);
      fetchProducts();
    }
  }, []);

  const fetchProducts = async () => {
    const token = localStorage.getItem('token'); // Retrieve the token from localStorage
    try {
      const response = await axios.get('http://localhost:9090/seller/products/getProducts', {
        headers: {
          Authorization: `Bearer ${token}` // Include token in the Authorization header
        }
      });
      setProducts(response.data);
      setFilteredProducts(response.data);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  const filterProducts = (category, order, search) => {
    let filtered = [...products];

    if (category) {
      filtered = filtered.filter((product) => product.category === category);
    }

    if (search) {
      filtered = filtered.filter((product) => product.name.toLowerCase().includes(search.toLowerCase()));
    }

    if (order === 'lowToHigh') {
      filtered.sort((a, b) => a.price - b.price);
    } else if (order === 'highToLow') {
      filtered.sort((a, b) => b.price - a.price);
    }

    setFilteredProducts(filtered);
  };

  const handleAddToCart = (product) => {
    AddToCart(product);
  };

  const handleSearchFocus = () => {
    setIsSearchFocused(true);
  };

  const handleSearchBlur = () => {
    setIsSearchFocused(false);
  };

  const handleSearchChangeFromNavbar = (search) => {
    setSearchTerm(search);
    filterProducts(filterCategory, sortOrder, search);
  };

  const handleCategoryChange = (event) => {
    const category = event.target.value;
    setFilterCategory(category);
    filterProducts(category, sortOrder, searchTerm);
  };

  const handleSortOrderChange = (event) => {
    const order = event.target.value;
    setSortOrder(order);
    filterProducts(filterCategory, order, searchTerm);
  };

  const handleViewDetails = (id) => {
    navigate(`/fetchProductDetails/${id}`); 
  };

  return (
    <>
      <Navbar onSearchFocus={handleSearchFocus} onSearchChange={handleSearchChangeFromNavbar} />
      <Box sx={{ display: 'flex', padding: 2, flexDirection: 'column' }}>
        {(!isLoggedIn || !isSearchFocused) && (
          <>
            <Box className="slider">
              <OfferSlider />
            </Box>

            <Box className="image-container">
              <Box className="image-row">
                <img src={Home_essentials} alt="Home Essentials" />
                <img src={kids_fashion} alt="Kids Fashion" />
                <img src={Kitchen_must_haves} alt="Kitchen Must Haves" />
                <img src={Laptops_and_Tablets} alt="Laptops and Tablets" />
                <img src={men_fashion} alt="Men Fashion" />
                <img src={Smart_Televisions} alt="Smart Televisions" />
              </Box>
            </Box>
          </>
        )}

        {isLoggedIn && (
          <Box sx={{ display: 'flex', width: '100%' }}>
            {isSearchFocused && (
              <Box sx={{ width: '20%', marginRight: 2 }}>
                <Typography variant="h6">Filters</Typography>

                <TextField
                  variant="outlined"
                  placeholder="Search by name..."
                  fullWidth
                  margin="normal"
                  value={searchTerm}
                  onFocus={handleSearchFocus}
                  onBlur={handleSearchBlur}
                  onChange={(e) => handleSearchChangeFromNavbar(e.target.value)}
                  InputLabelProps={{
                    shrink: !!searchTerm,
                  }}
                  sx={{ height: '40px', marginBottom: 2 }}
                />

                <FormControl fullWidth margin="normal" className="custom-select" sx={{ height: '40px', marginBottom: 2 }}>
                  <InputLabel className={filterCategory ? 'shrink' : ''}>Category</InputLabel>
                  <Select value={filterCategory} onChange={handleCategoryChange} variant="outlined">
                    <MenuItem value=""><em>All</em></MenuItem>
                    <MenuItem value="Fashion">Fashion</MenuItem>
                    <MenuItem value="Mobiles">Mobiles</MenuItem>
                    <MenuItem value="Electronics">Electronics</MenuItem>
                    <MenuItem value="Home">Home</MenuItem>
                  </Select>
                </FormControl>

                <FormControl fullWidth margin="normal" className="custom-select" sx={{ height: '40px' }}>
                  <InputLabel className={sortOrder ? 'shrink' : ''}>Sort By</InputLabel>
                  <Select value={sortOrder} onChange={handleSortOrderChange} variant="outlined">
                    <MenuItem value=""><em>None</em></MenuItem>
                    <MenuItem value="lowToHigh">Price: Low to High</MenuItem>
                    <MenuItem value="highToLow">Price: High to Low</MenuItem>
                  </Select>
                </FormControl>
              </Box>
            )}

            {isSearchFocused && (
              <Box className="product-grid" sx={{ width: '80%' }}>
                {filteredProducts.length > 0 ? (
                  filteredProducts.map((product) => (
                    
                    <Box
  key={product.id}
  className="product-card"
  sx={{
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between', // Ensures that content is spaced out
    alignItems: 'center',
    height: '400px', // Set a fixed height for the card
    border: '1px solid #ddd', // Optional: border for better separation
    borderRadius: '8px', // Optional: rounded corners
    padding: '10px', // Optional: add padding for aesthetics
    backgroundColor: '#f9f9f9', // Optional: light background color
  }}
>
  <img
    src={productImages[product.id] || 'path/to/default/image.jpg'}
    alt={product.name}
    className="product-image"
    style={{
      width: '100%', // Full width
      height: '200px', // Fixed height for consistency
      objectFit: 'cover', // Ensure aspect ratio is maintained
    }}
    onError={(e) => {
      e.target.src = 'path/to/default/image.jpg'; // Fallback image
    }}
  />
  <Typography variant="h6" className="product-name" sx={{ textAlign: 'center' }}>
    {product.name}
  </Typography>
  <Typography variant="body2" className="product-category" sx={{ textAlign: 'center' }}>
    {product.category}
  </Typography>
  <Typography variant="body1" className="product-price" sx={{ textAlign: 'center' }}>
    ₹{product.price}
  </Typography>

  <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', marginTop: 'auto' }}>
    <Button
      variant="contained"
      color="primary"
      onClick={() => handleAddToCart(product)}
      sx={{
        padding: '10px 20px',
        flexGrow: 1,
        marginRight: '5px',
      }}
    >
      Add to Cart
    </Button>
    <ToastContainer />
    <Button
      variant="outlined"
      color="primary"
      onClick={() => handleViewDetails(product.id)}
      sx={{
        padding: '10px 20px',
        flexGrow: 1,
        marginLeft: '5px',
      }}
    >
      View
    </Button>
  </Box>


                    </Box>
                  ))
                ) : (
                  <Typography variant="body1">No products found.</Typography>
                )}
              </Box>
            )}
          </Box>
        )}
      </Box>
    </>
  );
};

export default HomePage;*/


import React, { useEffect, useState } from 'react';
import { Box, Typography, FormControl, InputLabel, Select, MenuItem, TextField, Button } from '@mui/material';
import axios from 'axios';
import '../Comp_css/HomePage.css'; 
import '../Comp_css/slider.css'; 
import OfferSlider from '../Components/OfferSlider';
import { useNavigate } from 'react-router-dom';
import Navbar from '../Components/Navbar'; 
import AddToCart from '../Components/AddToCart';
import { ToastContainer } from 'react-toastify';

// Importing Category Images
import Home_essentials from "../images/Home_essentials.avif";
import kids_fashion from "../images/kids_fashion.avif";
import Kitchen_must_haves from "../images/Kitchen_must_haves.avif";
import Laptops_and_Tablets from "../images/Laptops_and_Tablets.avif";
import men_fashion from "../images/men_fashion.avif";
import Smart_Televisions from "../images/Smart_Televisions.avif";
import Footer from '../Components/Footer';

const HomePage = () => {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [filterCategory, setFilterCategory] = useState('');
  const [sortOrder, setSortOrder] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      setIsLoggedIn(true);
      fetchProducts();
    }
  }, []);

  const fetchProducts = async () => {
    const token = localStorage.getItem('token'); // Retrieve the token from localStorage
    try {
      const response = await axios.get('http://localhost:9090/seller/products/getProducts', {
        headers: {
          Authorization: `Bearer ${token}` // Include token in the Authorization header
        }
      });
      setProducts(response.data);
      setFilteredProducts(response.data);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  const filterProducts = (category, order, search) => {
    let filtered = [...products];

    if (category) {
      filtered = filtered.filter((product) => product.category === category);
    }

    if (search) {
      filtered = filtered.filter((product) => product.name.toLowerCase().includes(search.toLowerCase()));
    }

    if (order === 'lowToHigh') {
      filtered.sort((a, b) => a.price - b.price);
    } else if (order === 'highToLow') {
      filtered.sort((a, b) => b.price - a.price);
    }

    setFilteredProducts(filtered);
  };

  const handleAddToCart = (product) => {
    AddToCart(product);
  };

  const handleSearchFocus = () => {
    setIsSearchFocused(true);
  };

  const handleSearchBlur = () => {
    setIsSearchFocused(false);
  };

  const handleSearchChangeFromNavbar = (search) => {
    setSearchTerm(search);
    filterProducts(filterCategory, sortOrder, search);
  };

  const handleCategoryChange = (event) => {
    const category = event.target.value;
    setFilterCategory(category);
    filterProducts(category, sortOrder, searchTerm);
  };

  const handleSortOrderChange = (event) => {
    const order = event.target.value;
    setSortOrder(order);
    filterProducts(filterCategory, order, searchTerm);
  };

  const handleViewDetails = (id) => {
    navigate(`/fetchProductDetails/${id}`);
  };

  return (
    <>
      <Navbar onSearchFocus={handleSearchFocus} onSearchChange={handleSearchChangeFromNavbar} />
      <Box sx={{ display: 'flex', padding: 2, flexDirection: 'column' }}>
        {(!isLoggedIn || !isSearchFocused) && (
          <>
            <Box className="slider">
              <OfferSlider />
            </Box>

            <Box className="image-container">
              <Box className="image-row">
                <img src={Home_essentials} alt="Home Essentials" />
                <img src={kids_fashion} alt="Kids Fashion" />
                <img src={Kitchen_must_haves} alt="Kitchen Must Haves" />
                <img src={Laptops_and_Tablets} alt="Laptops and Tablets" />
                <img src={men_fashion} alt="Men Fashion" />
                <img src={Smart_Televisions} alt="Smart Televisions" />
              </Box>
            </Box>
          </>
        )}

        {isLoggedIn && (
          <Box sx={{ display: 'flex', width: '100%' }}>
            {isSearchFocused && (
              <Box sx={{ width: '20%', marginRight: 2 }}>
                <Typography variant="h6">Filters</Typography>

                <TextField
                  variant="outlined"
                  placeholder="Search by name..."
                  fullWidth
                  margin="normal"
                  value={searchTerm}
                  onFocus={handleSearchFocus}
                  onBlur={handleSearchBlur}
                  onChange={(e) => handleSearchChangeFromNavbar(e.target.value)}
                  InputLabelProps={{
                    shrink: !!searchTerm,
                  }}
                  sx={{ height: '40px', marginBottom: 2 }}
                />

                <FormControl fullWidth margin="normal" className="custom-select" sx={{ height: '40px', marginBottom: 2 }}>
                  <InputLabel className={filterCategory ? 'shrink' : ''}>Category</InputLabel>
                  <Select value={filterCategory} onChange={handleCategoryChange} variant="outlined">
                    <MenuItem value=""><em>All</em></MenuItem>
                    <MenuItem value="Fashion">Fashion</MenuItem>
                    <MenuItem value="Mobiles">Mobiles</MenuItem>
                    <MenuItem value="Electronics">Electronics</MenuItem>
                    <MenuItem value="Home">Home</MenuItem>
                  </Select>
                </FormControl>

                <FormControl fullWidth margin="normal" className="custom-select" sx={{ height: '40px' }}>
                  <InputLabel className={sortOrder ? 'shrink' : ''}>Sort By</InputLabel>
                  <Select value={sortOrder} onChange={handleSortOrderChange} variant="outlined">
                    <MenuItem value=""><em>None</em></MenuItem>
                    <MenuItem value="lowToHigh">Price: Low to High</MenuItem>
                    <MenuItem value="highToLow">Price: High to Low</MenuItem>
                  </Select>
                </FormControl>
              </Box>
            )}

            {isSearchFocused && (
              <Box className="product-grid" sx={{ width: '80%' }}>
                {filteredProducts.length > 0 ? (
                  filteredProducts.map((product) => (
                    <Box
                      key={product.id}
                      className="product-card"
                      sx={{
                        display: 'flex',
                        flexDirection: 'column',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        height: '400px',
                        border: '1px solid #ddd',
                        borderRadius: '8px',
                        padding: '10px',
                        backgroundColor: '#f9f9f9',
                      }}
                    >
                      <img
  src={product.imageurl ? product.imageurl : 'http://localhost:9090/images/default_image.jpg'}
  alt={product.name}
  className="product-image"
  style={{
    width: '100%',
    height: '200px',
    objectFit: 'cover',
  }}
  onError={(e) => {
    e.target.src = 'http://localhost:9090/images/default_image.jpg'; // Fallback image
  }}
/>
                      <Typography variant="h6" className="product-name" sx={{ textAlign: 'center' }}>
                        {product.name}
                      </Typography>
                      <Typography variant="body2" className="product-category" sx={{ textAlign: 'center' }}>
                        {product.category}
                      </Typography>
                      <Typography variant="body1" className="product-price" sx={{ textAlign: 'center' }}>
                        ₹{product.price}
                      </Typography>

                      <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', marginTop: 'auto' }}>
                        <Button
                          variant="contained"
                          color="primary"
                          onClick={() => handleAddToCart(product)}
                          sx={{
                            padding: '10px 20px',
                            flexGrow: 1,
                            marginRight: '5px',
                          }}
                        >
                          Add to Cart
                        </Button>
                        <ToastContainer />
                        <Button
                          variant="outlined"
                          onClick={() => handleViewDetails(product.id)}
                          sx={{
                            padding: '10px 20px',
                            flexGrow: 1,
                          }}
                        >
                          View Details
                        </Button>
                      </Box>
                    </Box>
                  ))
                ) : (
                  <Typography>No products found.</Typography>
                )}
              </Box>
            )}
          </Box>
        )}
      </Box>
      <Footer/>
    </>
  );
};

export default HomePage;

