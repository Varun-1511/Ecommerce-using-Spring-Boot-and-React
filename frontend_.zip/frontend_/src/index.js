// src/index.js
import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import store from './redux/store'; // Import your Redux store
import App from './App';
import theme from './theme'; // Optional: Your Material UI theme
import { ThemeProvider } from '@mui/material/styles';
import { BrowserRouter } from 'react-router-dom';

ReactDOM.render(
  <Provider store={store}> {/* Provide the Redux store */}
    <ThemeProvider theme={theme}> {/* Optional: Use Material UI theme */}
      <BrowserRouter>
      <App />
      </BrowserRouter>
    </ThemeProvider>
  </Provider>,
  document.getElementById('root') // Ensure this matches your index.html
);
