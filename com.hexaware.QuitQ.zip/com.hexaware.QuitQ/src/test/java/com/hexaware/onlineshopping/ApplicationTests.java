package com.hexaware.onlineshopping;

import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.hexaware.onlineshopping.Entities.ProductData;
import com.hexaware.onlineshopping.Entities.SellerData;
import com.hexaware.onlineshopping.Entities.UserData;
import com.hexaware.onlineshopping.Repositories.ProductDataRepository;
import com.hexaware.onlineshopping.Repositories.SellerDataRepository;
import com.hexaware.onlineshopping.Repositories.UserDataRepository;


@SpringBootTest
class ApplicationTests {
	@Autowired
	private UserDataRepository userRep;
	@Autowired
	private ProductDataRepository prodRep;
	@Autowired
	private SellerDataRepository sellerRep;


	@Test
	void addUser() {
		UserData u=new UserData();
		u.setName("ramya");
		u.setPassword("ramya123");
		u.setEmail("ramya@gmail.com");
		u.setRoles("ROLE_USER");
		userRep.save(u);
        
		
	}
	@Test
	void deleteUser() {
		userRep.deleteById(9);
	}
	
	@Test
	void updateUser() {
	    UserData actualUser = userRep.findById(6).orElse(null);  
	    
	    if (actualUser != null) {
	        actualUser.setName("jennie");
	        userRep.save(actualUser);
	        
	        assertEquals("jennie", actualUser.getName());
	    } else {
	        fail("User with ID 6 not found");
	    }
	}
	
	@Test
	void getUsers() {
	    int initialUserCount = userRep.findAll().size();

	    UserData newUser = new UserData();
	    newUser.setName("Test User");
	    userRep.save(newUser);

	    int updatedUserCount = userRep.findAll().size();

	    assertEquals(initialUserCount + 1, updatedUserCount);
	}
    
	@Test
	void addProduct() {
	    ProductData p = new ProductData();
	    p.setName("t-shirt");
	    p.setPrice(200.8);
	    p.setCategory("fashion");
	    p.setStockNumber(300);

	    SellerData existingSeller = sellerRep.findById(1).orElse(null); 
	    if (existingSeller == null) {
	        SellerData newSeller = new SellerData();
	        newSeller.setName("Seller Name");
	        newSeller.setEmail("styles@gmail.com");
	        sellerRep.save(newSeller);  
	        p.setSeller(newSeller);
	    } else {
	        p.setSeller(existingSeller);
	    }

	    prodRep.save(p);
	}
	
	@Test
	void updateProduct() {
	    ProductData existingProduct = prodRep.findById(1).orElseThrow(() -> new RuntimeException("Product not found"));

	    existingProduct.setName("Round neck T-shirt");
	    existingProduct.setPrice(250.5);
	    existingProduct.setCategory("Fashion");
	    existingProduct.setStockNumber(500);

	    SellerData existingSeller = sellerRep.findById(2).orElseThrow(() -> new RuntimeException("Seller not found"));
	    
	    existingProduct.setSeller(existingSeller);

	    prodRep.save(existingProduct);

	    ProductData updatedProduct = prodRep.findById(1).orElseThrow(() -> new RuntimeException("Product not found"));
	    assertEquals("Round neck T-shirt", updatedProduct.getName());
	    assertEquals(250.5, updatedProduct.getPrice());
	    assertEquals("Fashion", updatedProduct.getCategory());
	    assertEquals(500, updatedProduct.getStockNumber());
	    assertEquals(existingSeller.getId(), updatedProduct.getSeller().getId());
	}
	
	@Test
	void getProducts() {
	    int initialUserCount = prodRep.findAll().size();

	    ProductData newProduct = new ProductData();
	    newProduct.setName("Test User");
	    prodRep.save(newProduct);

	    int updatedUserCount = prodRep.findAll().size();

	    assertEquals(initialUserCount + 1, updatedUserCount);
	}
	
	@Test
	void setProductStockToZero() {
	    ProductData existingProduct = prodRep.findById(8).orElseThrow(() -> new RuntimeException("Product not found"));

	    existingProduct.setStockNumber(0);

	    prodRep.save(existingProduct);

	    ProductData updatedProduct = prodRep.findById(8).orElseThrow(() -> new RuntimeException("Product not found"));
	    assertEquals(0, updatedProduct.getStockNumber());
	}

	
	



}
