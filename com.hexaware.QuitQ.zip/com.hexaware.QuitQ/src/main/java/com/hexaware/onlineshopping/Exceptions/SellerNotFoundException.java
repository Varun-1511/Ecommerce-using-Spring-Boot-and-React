package com.hexaware.onlineshopping.Exceptions;

public class SellerNotFoundException extends RuntimeException {
    
    public SellerNotFoundException(String message) {
        super(message);
    }
}