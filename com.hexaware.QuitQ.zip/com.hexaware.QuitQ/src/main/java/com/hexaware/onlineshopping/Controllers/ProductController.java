package com.hexaware.onlineshopping.Controllers;

import com.hexaware.onlineshopping.DTOs.ProductDTO;
import com.hexaware.onlineshopping.Entities.ProductData;
import com.hexaware.onlineshopping.Services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/seller/products")
public class ProductController {

    @Autowired
    private ProductService prodSer;
    

    @PostMapping("/addProduct")
    public ProductDTO addProduct(@RequestBody ProductData product) {
        return prodSer.addProduct(product);
    }


    @PutMapping("/updateProduct/{id}")
    public ProductDTO updateProduct(@PathVariable int id, @RequestBody ProductDTO productDTO) {
        return prodSer.updateProduct(id, productDTO);
    }

    @PatchMapping("/markOutOfStock/{id}")
    public ProductDTO markOutOfStock(@PathVariable int id) {
        return prodSer.markOutOfStock(id);
    }

    
    @GetMapping("/getProducts")
    public ResponseEntity<List<ProductDTO>> getAllProducts() {
        List<ProductDTO> products = prodSer.getProducts(); 
        return ResponseEntity.ok(products); 
    }
    
    @GetMapping("/getProductbyid")
    public ResponseEntity<ProductDTO> getProductById(@RequestParam int id) {
        ProductDTO productDTO = prodSer.getProductById(id);
        return ResponseEntity.ok(productDTO);
    }


 
}
