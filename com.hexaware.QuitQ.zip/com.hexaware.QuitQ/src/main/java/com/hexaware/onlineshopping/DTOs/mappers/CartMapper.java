package com.hexaware.onlineshopping.DTOs.mappers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hexaware.onlineshopping.DTOs.CartDTO;
import com.hexaware.onlineshopping.DTOs.CartItemDTO;
import com.hexaware.onlineshopping.Entities.CartData;
import com.hexaware.onlineshopping.Entities.CartItem;

@Component
public class CartMapper {

    @Autowired
    private ModelMapper modelMapper;

    public CartDTO toDTO(CartData cart) {
        return modelMapper.map(cart, CartDTO.class);
    }

    public CartItemDTO toDTO(CartItem item) {
        return modelMapper.map(item, CartItemDTO.class);
    }

    public CartData toEntity(CartDTO cartDTO) {
        return modelMapper.map(cartDTO, CartData.class);
    }
}
