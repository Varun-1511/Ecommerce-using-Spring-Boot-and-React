package com.hexaware.onlineshopping.Services;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hexaware.onlineshopping.Entities.AdminData;
import com.hexaware.onlineshopping.Entities.SellerData;
import com.hexaware.onlineshopping.Entities.UserData;
import com.hexaware.onlineshopping.Entities.UserDataDetails;
import com.hexaware.onlineshopping.Repositories.SellerDataRepository;
import com.hexaware.onlineshopping.Repositories.UserDataRepository;

@Service
public class UserDataService implements UserDetailsService {

	
	@Autowired
	private PasswordEncoder encoder;
	
	@Autowired
	private UserDataRepository repository;
	
	@Autowired
	private SellerDataRepository sellerRepository;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		   Optional<UserData> userDetail = repository.findByName(username);

	        return userDetail.map(UserDataDetails::new)
	                .orElseThrow(() -> new UsernameNotFoundException("User not found " + username));
      
	}
	
	 public String addUser(UserData userData) {
	        if (userData.getPassword() == null || userData.getPassword().isEmpty()) {
	            throw new IllegalArgumentException("Password cannot be null or empty");
	        }
	        userData.setPassword(encoder.encode(userData.getPassword()));
	        repository.save(userData);

	        // Check the role of the user and save in the appropriate table
	        if (userData.getRoles().contains("ROLE_SELLER")) {
	            // Save seller-specific details in seller_data
	            SellerData seller = new SellerData();
	            seller.setName(userData.getName());
	            seller.setEmail(userData.getEmail());
	            seller.setPassword(userData.getPassword()); // same encoded password
	            sellerRepository.save(seller);
	        }

//	        if (userData.getRoles().contains("ROLE_ADMIN")) {
//	            // Save admin-specific details in admin_data (if needed)
//	            AdminData admin = new AdminData();
//	            admin.setName(userData.getName());
//	            admin.setEmail(userData.getEmail());
//	            admin.setPassword(userData.getPassword());
//	            adminRepository.save(admin);
//	        }

	        return "User Added Successfully...";
	    }

	
	public boolean deleteUser(int id) {
        Optional<UserData> user = repository.findById(id);
        if (user.isPresent()) {
        	repository.deleteById(id);
            return true;
        }
        return false;
    }
	
	public boolean updateUser(int id, UserData updatedUserInfo) {
        Optional<UserData> existingUser = repository.findById(id);
        if (existingUser.isPresent()) {
            UserData user = existingUser.get();
            user.setName(updatedUserInfo.getName()); 
            user.setEmail(updatedUserInfo.getEmail()); 
            repository.save(user);
            return true;
        }
        return false;
    }

    public List<UserData> getAllUsers() {
        return repository.findAll();
    }
    
    public Optional<UserData> findUserByUsername(String username) {
        return repository.findByName(username);
    }
    public UserData getUserById(int id) {
        return repository.findById(id).orElse(null); 
    }

    public int findUserIdByUsername(String username) {
        return findUserByUsername(username)
                .map(UserData::getUid)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }
	
	

}