package com.hexaware.onlineshopping.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.hexaware.onlineshopping.Entities.CategoryData;
import com.hexaware.onlineshopping.Services.CategoryDataService;

import java.util.List;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/admin/categories")
public class CategoryController {

    @Autowired
    private CategoryDataService catSer;

    @GetMapping("/getCategories")
    @PreAuthorize("hasRole('ADMIN')")
    public List<CategoryData> getAllCategories() {
        return catSer.getAllCategories();
    }

    @GetMapping("/getCategoryById/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<CategoryData> getCategoryById(@PathVariable int id) {
        return catSer.getCategoryById(id)
            .map(ResponseEntity::ok)
            .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping("/addCategory")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<CategoryData> addCategory(@RequestBody CategoryData category) {
        CategoryData newCategory = catSer.addCategory(category);
        return ResponseEntity.ok(newCategory);
    }

    @PutMapping("/updateCategory/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<CategoryData> updateCategory(@PathVariable int id, @RequestBody CategoryData updatedCategory) {
        return ResponseEntity.ok(catSer.updateCategory(id, updatedCategory));
    }

    @DeleteMapping("/deleteCategory/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteCategory(@PathVariable int id) {
        catSer.deleteCategory(id);
        return ResponseEntity.ok().build();
    }
}
