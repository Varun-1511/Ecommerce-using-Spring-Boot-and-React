package com.hexaware.onlineshopping.DTOs;

public class CartItemDTO {
    private int productId;
    private String productName;
    private double price; // Change this to double
    private int quantity;
    private String imageurl; // Ensure this is included
    
    public CartItemDTO() {
    }

    public CartItemDTO(int productId, String productName, double price, int quantity, String imageurl) {
        this.productId = productId;
        this.productName = productName;
        this.price = price;
        this.quantity = quantity;
        this.imageurl = imageurl; 
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public double getPrice() { // Change return type to double
        return price;
    }

    public void setPrice(double price) { // Change parameter type to double
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

	public String getImageurl() {
		return imageurl;
	}

	public void setImageurl(String imageurl) {
		this.imageurl = imageurl;
	}
    
}
