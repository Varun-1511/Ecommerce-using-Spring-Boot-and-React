package com.hexaware.onlineshopping.Repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hexaware.onlineshopping.Entities.SellerData;

@Repository
public interface SellerDataRepository extends JpaRepository<SellerData, Integer> {
	Optional<SellerData> findByName(String name);

}

