package com.hexaware.onlineshopping.Repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hexaware.onlineshopping.Entities.OrderData;

@Repository
public interface OrderDataRepository extends JpaRepository<OrderData, Integer> {
	@Query("SELECT o FROM OrderData o WHERE o.status = 'COMPLETED'")
	List<OrderData> findCompletedOrders();
	
	List<OrderData> findBySellerId(int sellerId);
	
	List<OrderData> findAll();

}
