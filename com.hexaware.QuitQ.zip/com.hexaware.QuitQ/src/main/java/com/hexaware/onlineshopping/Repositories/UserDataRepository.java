package com.hexaware.onlineshopping.Repositories;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hexaware.onlineshopping.Entities.UserData;

public interface UserDataRepository extends JpaRepository<UserData, Integer> {

	Optional<UserData> findByName(String username);
	
}