package com.hexaware.onlineshopping.Controllers;

import com.hexaware.onlineshopping.DTOs.CartDTO;
import com.hexaware.onlineshopping.DTOs.CartItemDTO;
import com.hexaware.onlineshopping.Entities.CartItem;
import com.hexaware.onlineshopping.Entities.UserData;
import com.hexaware.onlineshopping.Entities.UserDataDetails;
import com.hexaware.onlineshopping.Services.CartService;
import com.hexaware.onlineshopping.Services.UserDataService;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/users/cart")
public class CartController {

    @Autowired
    private CartService cartSer;

    @Autowired
    private UserDataService userSer;

    @PostMapping("/addToCart")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<CartDTO> addProductToCart(@RequestParam int productId, @RequestParam int quantity) {
        int userId = getCurrentUserId();
        
        CartDTO cart = cartSer.addProductToCart(userId, productId, quantity);
        System.out.println("User ID: " + userId);
        return ResponseEntity.ok(cart);
    }

    



    @PutMapping("/updateCart")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<CartDTO> updateProductQuantity(@RequestParam int productId, @RequestParam int quantity) {
        int userId = getCurrentUserId();
        CartDTO cart = cartSer.updateProductQuantity(userId, productId, quantity);
        return ResponseEntity.ok(cart);
    }

    @GetMapping("/viewCart")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<CartDTO> getUserCart() {
        int userId = getCurrentUserId();
        
        CartDTO cart = cartSer.getUserCart(userId);
        return ResponseEntity.ok(cart);
    }
    
    @GetMapping("/items")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<List<CartItemDTO>> getCartItems() {
        int userId = getCurrentUserId(); // Assuming you have a method to get the current user's ID
        List<CartItemDTO> cartItems = cartSer.getCartItems(userId);
        return ResponseEntity.ok(cartItems);
    }
    
    @DeleteMapping("/removeItem")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<CartDTO> removeItemFromCart(@RequestParam int productId) { 
        int userId = getCurrentUserId();
        CartDTO updatedCart = cartSer.removeItemFromCart(userId, productId);
        return ResponseEntity.ok(updatedCart);
    }


    private int getCurrentUserId() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !(auth.getPrincipal() instanceof UserDataDetails)) {
            throw new RuntimeException("User is not authenticated");
        }
        UserDataDetails userDetails = (UserDataDetails) auth.getPrincipal();
        String username = userDetails.getUsername();
        
        Optional<UserData> optionalUser = userSer.findUserByUsername(username);
        if (!optionalUser.isPresent()) {
            throw new RuntimeException("User not found");
        }
        
        UserData user = optionalUser.get();
        return user.getUid();
    }

}
