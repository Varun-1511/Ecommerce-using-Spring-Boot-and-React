package com.hexaware.onlineshopping.Entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class ProductData {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String name;
	private String category;
	private Double price;
	private Integer stockNumber;
	private String Description;
	private String imageurl;

	@ManyToOne
	@JoinColumn(name = "seller_id")
	private SellerData seller;

	public ProductData() {
		super();
	}

	

	public ProductData(int id, String name, String category, Double price, Integer stockNumber, String description,
			SellerData seller, String imageurl) {
		super();
		this.id = id;
		this.name = name;
		this.category = category;
		this.price = price;
		this.stockNumber = stockNumber;
		Description = description;
		this.seller = seller;
		this.imageurl=imageurl;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Integer getStockNumber() {
		return stockNumber;
	}

	public void setStockNumber(Integer stockNumber) {
		this.stockNumber = stockNumber;
	}

	public SellerData getSeller() {
		return seller;
	}

	public void setSeller(SellerData seller) {
		this.seller = seller;
	}



	public String getDescription() {
		return Description;
	}



	public void setDescription(String description) {
		Description = description;
	}



	public String getImageurl() {
		return imageurl;
	}



	public void setImageurl(String imageurl) {
		this.imageurl = imageurl;
	}
	
	
}
