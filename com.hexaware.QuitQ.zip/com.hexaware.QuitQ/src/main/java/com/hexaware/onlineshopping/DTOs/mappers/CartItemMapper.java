package com.hexaware.onlineshopping.DTOs.mappers;

import com.hexaware.onlineshopping.DTOs.CartItemDTO;
import com.hexaware.onlineshopping.Entities.CartItem;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
public class CartItemMapper {

    private final ModelMapper modelMapper;

    public CartItemMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public CartItemDTO toDTO(CartItem cartItem) {
        CartItemDTO dto = modelMapper.map(cartItem, CartItemDTO.class);
        
        if (cartItem.getProduct() != null) {
            String imageUrl = cartItem.getProduct().getImageurl();
            dto.setImageurl(imageUrl);
            System.out.println("Mapped Image URL: " + imageUrl); 
            dto.setPrice(cartItem.getProduct().getPrice());
        } else {
            dto.setImageurl(null);
            System.out.println("No Product found for CartItem ID: " + cartItem.getId());
        }
        
        return dto;
    }



    public CartItem toEntity(CartItemDTO cartItemDTO) {
        return modelMapper.map(cartItemDTO, CartItem.class);
    }
}
