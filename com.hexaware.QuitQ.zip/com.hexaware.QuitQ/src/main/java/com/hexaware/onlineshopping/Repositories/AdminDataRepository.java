package com.hexaware.onlineshopping.Repositories;

public interface AdminDataRepository {

}
