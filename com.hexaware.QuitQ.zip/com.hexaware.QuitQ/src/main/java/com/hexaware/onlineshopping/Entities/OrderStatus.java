package com.hexaware.onlineshopping.Entities;

public enum OrderStatus {
    PENDING,
    SHIPPED,
    DELIVERED,
    CANCELED,
    COMPLETED
}
