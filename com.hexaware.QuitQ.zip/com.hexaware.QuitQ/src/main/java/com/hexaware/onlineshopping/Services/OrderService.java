package com.hexaware.onlineshopping.Services;

import com.hexaware.onlineshopping.DTOs.OrderDTO;
import com.hexaware.onlineshopping.DTOs.SellerDTO;
import com.hexaware.onlineshopping.DTOs.mappers.OrderMapper;
import com.hexaware.onlineshopping.Entities.CartItem;
import com.hexaware.onlineshopping.Entities.OrderData;
import com.hexaware.onlineshopping.Entities.OrderStatus;
import com.hexaware.onlineshopping.Entities.ProductData;
import com.hexaware.onlineshopping.Entities.SellerData;
import com.hexaware.onlineshopping.Entities.UserData;
import com.hexaware.onlineshopping.Repositories.OrderDataRepository;
import com.hexaware.onlineshopping.Repositories.ProductDataRepository;
import com.hexaware.onlineshopping.Repositories.SellerDataRepository;
import com.hexaware.onlineshopping.Repositories.UserDataRepository;
import com.hexaware.onlineshopping.DTOs.mappers.CartItemMapper; 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrderService {

    @Autowired
    private OrderDataRepository ordRep;

    @Autowired
    private SellerDataRepository sellerRep;
    @Autowired
    private UserDataRepository userRep;
    
    @Autowired
    private ProductDataRepository ProdRep;

    @Autowired
    private OrderMapper orderMapper;

    @Autowired
    private CartItemMapper cartItemMapper; 
    
    public OrderDTO placeOrder(int productid, int quantity) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth.getName();
        
        // Fetch user by username
        UserData user = userRep.findByName(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Fetch product by productId
        ProductData product = ProdRep.findById(productid)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        // Fetch seller from the product (assuming the product has a reference to the seller)
        SellerData seller = product.getSeller();
        
        // Create a new CartItem for the order
        CartItem cartItem = new CartItem();
        cartItem.setProduct(product);
        cartItem.setQuantity(quantity);
        cartItem.setPrice(product.getPrice());
        cartItem.setUser(user);

        // Create new OrderData
        OrderData orderData = new OrderData();
        orderData.setUser(user);
        orderData.setSeller(seller);
        orderData.setItems(Collections.singletonList(cartItem)); // Add the cart item to the order
        orderData.setStatus(OrderStatus.PENDING); // Set the initial status of the order
        orderData.setTotalAmount(cartItem.getPrice() * quantity); // Calculate the total amount

        // Save the order to the database
        ordRep.save(orderData);

        return orderMapper.toDTO(orderData); // Return the saved order as a DTO
    }

    
    private Double calculateTotalAmount(List<CartItem> items) {
        return items.stream()
                .mapToDouble(item -> item.getProduct().getPrice() * item.getQuantity())
                .sum();
    }

    public List<OrderDTO> getOrdersForSeller() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String sellerUsername = auth.getName();
        
        SellerData seller = sellerRep.findByName(sellerUsername)
                .orElseThrow(() -> new RuntimeException("Seller not found"));
        
        List<OrderData> orders = ordRep.findBySellerId(seller.getId());

        return orders.stream()
                     .map(orderMapper::toDTO) 
                     .collect(Collectors.toList());
    }

    public List<OrderDTO> getOrderHistory() {
        List<OrderData> orders = ordRep.findAll();
        for (OrderData order : orders) {
            System.out.println("Order ID: " + order.getId() + ", Items: " + order.getItems());
        }
        return orders.stream()
                     .map(order -> {
                         OrderDTO orderDTO = orderMapper.toDTO(order);
                         
                         if (order.getItems() == null) {
                             order.setItems(new ArrayList<>());
                         }
                         orderDTO.setItems(order.getItems().stream()
                                                  .map(cartItemMapper::toDTO)
                                                  .collect(Collectors.toList()));
                         return orderDTO;
                     })
                     .collect(Collectors.toList());
    }

}
