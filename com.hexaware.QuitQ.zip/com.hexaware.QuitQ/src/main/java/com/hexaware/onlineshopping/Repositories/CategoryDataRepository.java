package com.hexaware.onlineshopping.Repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hexaware.onlineshopping.Entities.CategoryData;

@Repository
public interface CategoryDataRepository extends JpaRepository<CategoryData, Integer> {

}
