package com.hexaware.onlineshopping.DTOs.mappers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hexaware.onlineshopping.DTOs.ProductDTO;
import com.hexaware.onlineshopping.Entities.ProductData;

@Component
public class ProductMapper {

    @Autowired
    private ModelMapper modelMapper;

    public ProductDTO toDTO(ProductData product) {
        return modelMapper.map(product, ProductDTO.class);
    }

    public ProductData toEntity(ProductDTO productDTO) {
        return modelMapper.map(productDTO, ProductData.class);
    }
}
