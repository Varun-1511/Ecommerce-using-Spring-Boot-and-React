package com.hexaware.onlineshopping.DTOs.mappers;

import com.hexaware.onlineshopping.DTOs.OrderDTO;
import com.hexaware.onlineshopping.Entities.OrderData;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class OrderMapper {

    @Autowired
    private ModelMapper modelMapper;

    public OrderDTO toDTO(OrderData order) {
        return modelMapper.map(order, OrderDTO.class);
    }

    public OrderData toEntity(OrderDTO orderDTO) {
        return modelMapper.map(orderDTO, OrderData.class);
    }
}
