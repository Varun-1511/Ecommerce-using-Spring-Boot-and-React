package com.hexaware.onlineshopping.Controllers;

import com.hexaware.onlineshopping.DTOs.OrderDTO;
import com.hexaware.onlineshopping.Services.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/seller/orders")
public class OrderController {

    @Autowired
    private OrderService ordSer;
    
    @PostMapping("/placeorder")
    public ResponseEntity<OrderDTO> placeOrder(@RequestParam int productid, @RequestParam int quantity) {
        try {
            OrderDTO createdOrder = ordSer.placeOrder(productid, quantity);
            return new ResponseEntity<>(createdOrder, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            // Log the error message for debugging purposes
            System.out.println("Error while placing order: " + e.getMessage());
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
    }


    @GetMapping("/viewOrders")
    @PreAuthorize("hasRole('SELLER')")
    public List<OrderDTO> getSellerOrders() {
        return ordSer.getOrdersForSeller(); 
    }

    @GetMapping("/viewOrderHistory")
    @PreAuthorize("hasRole('SELLER')")
    public List<OrderDTO> getOrderHistory() {
        return ordSer.getOrderHistory(); 
    }
}
