package com.hexaware.onlineshopping.Services;

import com.hexaware.onlineshopping.DTOs.CartDTO;
import com.hexaware.onlineshopping.DTOs.CartItemDTO;
import com.hexaware.onlineshopping.DTOs.mappers.CartMapper;
import com.hexaware.onlineshopping.Entities.CartData;
import com.hexaware.onlineshopping.Entities.CartItem;
import com.hexaware.onlineshopping.Entities.ProductData;
import com.hexaware.onlineshopping.Entities.UserData;
import com.hexaware.onlineshopping.Exceptions.ProductNotFoundException;
import com.hexaware.onlineshopping.Repositories.CartDataRepository;
import com.hexaware.onlineshopping.Repositories.CartItemRepository;
import com.hexaware.onlineshopping.Repositories.ProductDataRepository;
import com.hexaware.onlineshopping.Repositories.UserDataRepository;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.stream.Collectors;
import java.util.List;
import java.util.ArrayList;
import java.util.Optional;

@Service
public class CartService {

    @Autowired
    private CartDataRepository cartRep;


    @Autowired
    private ProductDataRepository productRep;


    @Autowired
    private CartMapper cartMapper; 


    @Autowired
    private UserDataRepository userRep;

    @Transactional
    public CartDTO addProductToCart(int userId, int productId, int quantity) {
        // Fetch the user based on userId
        UserData user = userRep.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with ID: " + userId));

        CartData cart = cartRep.findByUser_Uid(userId).orElse(new CartData());
        if (cart.getUser() == null) {
            cart.setUser(user);
        }

        if (cart.getItems() == null) {
            cart.setItems(new ArrayList<>());
        }

        ProductData product = productRep.findById(productId)
                .orElseThrow(() -> new ProductNotFoundException("Product not found with ID: " + productId));

        Optional<CartItem> existingItem = cart.getItems().stream()
                .filter(item -> item.getProduct().getId() == productId)
                .findFirst();

        if (existingItem.isPresent()) {
            CartItem item = existingItem.get();
            item.setQuantity(item.getQuantity() + quantity);
        } else {
            CartItem cartItem = new CartItem();
            cartItem.setProduct(product);
            cartItem.setQuantity(quantity);
            cartItem.setUser(user); // Use the fetched user object here
            cartItem.setCartData(cart);

            cart.getItems().add(cartItem);
        }

        double totalAmount = cart.getItems().stream()
                .mapToDouble(item -> item.getProduct().getPrice() * item.getQuantity())
                .sum();
        cart.setTotalAmount(totalAmount);

        cartRep.save(cart);

        // Create the CartDTO and set the userId
        CartDTO cartDTO = cartMapper.toDTO(cart);
        cartDTO.setUserId(userId); // Set the userId here

        return cartDTO; 
    }




    public CartDTO updateProductQuantity(int userId, int productId, int quantity) {
        CartData cart = cartRep.findByUser_Uid(userId)
                .orElseThrow(() -> new RuntimeException("Cart not found for user " + userId));

        ProductData product = productRep.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found with id " + productId));

        Optional<CartItem> existingItem = cart.getItems().stream()
                .filter(item -> item.getProduct().getId() == productId)
                .findFirst();

        if (existingItem.isPresent()) {
            CartItem item = existingItem.get();
            item.setQuantity(quantity);
        } else {
            CartItem cartItem = new CartItem();
            cartItem.setProduct(product);
            cartItem.setQuantity(quantity);
            cart.getItems().add(cartItem);
        }
        
        double totalAmount = cart.getItems().stream()
                .mapToDouble(item -> item.getProduct().getPrice() * item.getQuantity())
                .sum();
        cart.setTotalAmount(totalAmount);

        cartRep.save(cart);

        return cartMapper.toDTO(cart); 
    }

    public CartDTO getUserCart(int userId) {
        CartData cart = cartRep.findByUser_Uid(userId)
                .orElseThrow(() -> new RuntimeException("Cart not found"));

        return cartMapper.toDTO(cart); 
    }
    public List<CartItemDTO> getCartItems(int userId) {
        CartData cart = cartRep.findByUser_Uid(userId)
                .orElseThrow(() -> new RuntimeException("Cart not found for user " + userId));

        return cart.getItems().stream()
                .map(cartMapper::toDTO) // Map CartItem to CartItemDTO
                .collect(Collectors.toList());
    }
    
    public CartDTO removeItemFromCart(int userId, int productId) {
        CartData cart = cartRep.findByUser_Uid(userId)
                .orElseThrow(() -> new RuntimeException("Cart not found for user " + userId));

        Optional<CartItem> existingItem = cart.getItems().stream()
                .filter(item -> item.getProduct().getId() == productId)
                .findFirst();

        if (existingItem.isPresent()) {
            cart.getItems().remove(existingItem.get());
        } else {
            throw new RuntimeException("Item not found in cart with product ID: " + productId);
        }

        double totalAmount = cart.getItems().stream()
                .mapToDouble(item -> item.getProduct().getPrice() * item.getQuantity())
                .sum();
        cart.setTotalAmount(totalAmount);

        cartRep.save(cart);

        return cartMapper.toDTO(cart);
    }

}