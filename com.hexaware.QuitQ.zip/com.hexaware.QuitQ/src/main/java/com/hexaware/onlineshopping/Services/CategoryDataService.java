package com.hexaware.onlineshopping.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexaware.onlineshopping.Entities.CategoryData;
import com.hexaware.onlineshopping.Repositories.CategoryDataRepository;

@Service
public class CategoryDataService {
	
	@Autowired
    private CategoryDataRepository catRep;

    public List<CategoryData> getAllCategories() {
        return catRep.findAll();
    }

    public Optional<CategoryData> getCategoryById(int id) {
        return catRep.findById(id);
    }

    public CategoryData addCategory(CategoryData c) {
        return catRep.save(c);
    }
    
    public CategoryData updateCategory(int id, CategoryData updatedCategory) {
        return catRep.findById(id)
            .map(categoryData -> {
                categoryData.setName(updatedCategory.getName());
                categoryData.setDescription(updatedCategory.getDescription());
                return catRep.save(categoryData);
            })
            .orElseThrow(() -> new RuntimeException("Category not found with id: " + id));
    }


    public void deleteCategory(int id) {
        if (catRep.existsById(id)) {
            catRep.deleteById(id);
        } else {
            throw new RuntimeException("Category not found with id: " + id);
        }
    }

}
