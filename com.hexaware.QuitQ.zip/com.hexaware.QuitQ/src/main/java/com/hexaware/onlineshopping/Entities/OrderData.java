package com.hexaware.onlineshopping.Entities;

import java.util.List;
import java.util.stream.Collectors;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class OrderData {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@ManyToOne
	@JoinColumn(name = "user_id")
	private UserData user;

	@ManyToOne
	@JoinColumn(name = "seller_id")
	private SellerData seller;

	@OneToMany(mappedBy = "orderData", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private List<CartItem> items;

	@Enumerated(EnumType.STRING)
	private OrderStatus status;

	private Double totalAmount;

	// Default constructor
	public OrderData() {
		super();
	}

	// Parameterized constructor
	public OrderData(int id, UserData user, SellerData seller, List<CartItem> items, OrderStatus status,
			Double totalAmount) {
		this.id = id;
		this.user = user;
		this.seller = seller;
		this.items = items;
		this.status = status;
		this.totalAmount = totalAmount;
	}

	// Getters and Setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public UserData getUser() {
		return user;
	}

	public void setUser(UserData user) {
		this.user = user;
	}

	public SellerData getSeller() {
		return seller;
	}

	public void setSeller(SellerData seller) {
		this.seller = seller;
	}

	public List<CartItem> getItems() {
		return items;
	}

	public void setItems(List<CartItem> items) {
		this.items = items;
	}

	public OrderStatus getStatus() {
		return status;
	}

	public void setStatus(OrderStatus status) {
		this.status = status;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public List<ProductData> getProducts() {
		return items.stream().map(CartItem::getProduct).collect(Collectors.toList());
	}
}
