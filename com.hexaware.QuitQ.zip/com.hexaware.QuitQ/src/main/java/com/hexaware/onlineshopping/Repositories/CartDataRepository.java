package com.hexaware.onlineshopping.Repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hexaware.onlineshopping.Entities.CartData;

@Repository
public interface CartDataRepository extends JpaRepository<CartData, Integer> {
	@Query("SELECT c FROM CartData c JOIN FETCH c.items ci JOIN FETCH ci.product WHERE c.user.uid = :uid")
    Optional<CartData> findByUser_Uid(@Param("uid") int uid);
 
}

