package com.hexaware.onlineshopping.Services;

import com.hexaware.onlineshopping.DTOs.ProductDTO;
import com.hexaware.onlineshopping.Entities.ProductData;
import com.hexaware.onlineshopping.Repositories.ProductDataRepository;
import com.hexaware.onlineshopping.Repositories.SellerDataRepository;
import com.hexaware.onlineshopping.Entities.SellerData;
import com.hexaware.onlineshopping.Exceptions.ProductNotFoundException;
import com.hexaware.onlineshopping.Exceptions.SellerNotFoundException;
import com.hexaware.onlineshopping.DTOs.mappers.ProductMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService {

    @Autowired
    private ProductDataRepository prodRep;

    @Autowired
    private SellerDataRepository sellerRep;

    @Autowired
    private ProductMapper productMapper; 

    public ProductDTO addProduct(ProductData product) {
        // Get the currently authenticated seller's username
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String sellerUsername = auth.getName();
        
        // Find the seller by username, throw an exception if not found
        SellerData seller = sellerRep.findByName(sellerUsername)
                .orElseThrow(() -> new SellerNotFoundException("Seller with username " + sellerUsername + " not found."));

        // Set the seller for the product
        product.setSeller(seller);

        // Save the product in the repository
        ProductData savedProduct = prodRep.save(product);

        // Return the saved product mapped to a DTO
        return productMapper.toDTO(savedProduct); 
    }


    public ProductDTO updateProduct(int id, ProductDTO updatedProductDTO) {
        return prodRep.findById(id).map(product -> {
            //product.setName(updatedProductDTO.getName());
            //product.setPrice(updatedProductDTO.getPrice());
            // product.setCategory(updatedProductDTO.getCategory());
            product.setStockNumber(updatedProductDTO.getStockNumber());
            ProductData updatedProduct = prodRep.save(product);

            return productMapper.toDTO(updatedProduct); 
        }).orElseThrow(() -> new RuntimeException("Product not found"));
    }

    public ProductDTO markOutOfStock(int id) {
        return prodRep.findById(id).map(product -> {
            product.setStockNumber(0);
            ProductData updatedProduct = prodRep.save(product);

            return productMapper.toDTO(updatedProduct);
        }).orElseThrow(() -> new RuntimeException("Product not found"));
    }

    public List<ProductDTO> getProducts() {
        List<ProductData> products = prodRep.findAll(); 
        return products.stream()
                       .map(productMapper::toDTO) 
                       .collect(Collectors.toList()); 
    }
    
    public ProductDTO getProductById(int productId) {
        ProductData product = prodRep.findById(productId)
            .orElseThrow(() -> new ProductNotFoundException("Product not found with id: " + productId));
        
        return productMapper.toDTO(product);
    }


}
