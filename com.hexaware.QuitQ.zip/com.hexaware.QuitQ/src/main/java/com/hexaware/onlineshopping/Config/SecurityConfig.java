package com.hexaware.onlineshopping.Config;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.firewall.HttpFirewall;
import org.springframework.security.web.firewall.StrictHttpFirewall;

import com.hexaware.onlineshopping.Services.UserDataService;
import com.hexaware.onlineshopping.filter.JwtAuthFilter;
@Configuration
@EnableWebSecurity
public class SecurityConfig {

	@Autowired
	private JwtAuthFilter authFilter;
	

	@Bean
	public UserDetailsService userDetailsService() {
		return new UserDataService();
	}
	

	@Bean
	public HttpFirewall allowUrlEncodedSlashHttpFirewall() {
		StrictHttpFirewall firewall = new StrictHttpFirewall();
		firewall.setAllowUrlEncodedSlash(true);
		firewall.setAllowUrlEncodedPercent(true);
		firewall.setAllowUrlEncodedPeriod(true);
		firewall.setAllowBackSlash(true);
		firewall.setAllowSemicolon(true);
		firewall.setAllowUrlEncodedDoubleSlash(true);
		return firewall;
	}

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		return http.csrf(csrf -> csrf.disable()).authorizeHttpRequests(auth -> auth
				.requestMatchers("/auth/welcome", "/auth/addNewUser", "/auth/generateToken", "/auth/user/userProfile"
						)
				.permitAll()
				.requestMatchers("/images/**").permitAll()
				.requestMatchers("/auth/admin/adminProfile", "/auth/deleteUser/{id}", "/auth/getAllUsers",
						 "/admin/categories/getCategoryById/{id}",
						"/admin/categories/addCategory", "/admin/categories/updateCategory/{id}",
						"/admin/categories/deleteCategory/{id}")
				.hasRole("ADMIN")
				.requestMatchers("/admin/categories/getCategories").hasAnyRole("ADMIN" ,"SELLER")
				.requestMatchers("/auth/seller/sellerProfile", "/seller/products/addProduct",
						"/seller/products/updateProduct/{id}", "/seller/products/markOutOfStock/{id}",
						"/seller/orders/viewOrders", "/seller/orders/viewOrderHistory")
				.hasRole("SELLER")
				.requestMatchers("/seller/products/getProducts").hasAnyRole("USER","SELLER")
				.requestMatchers("/seller/orders/placeorder","/seller/products/getProductbyid","/users/cart/addToCart", "/users/cart/updateCart","/users/cart/removeItem", "/users/cart/viewCart","/users/cart/items","auth/updateUser/{id}","auth/getUserById/{id}")
				.hasRole("USER")
				.requestMatchers("/auth/user/**").hasAnyRole("USER", "SELLER", "ADMIN"))
				.sessionManagement(sess -> sess.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
				.addFilterBefore(authFilter, UsernamePasswordAuthenticationFilter.class).build();
	}

	@Bean
	public AuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
		provider.setUserDetailsService(userDetailsService());
		provider.setPasswordEncoder(passwordEncoder());
		return provider;
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
		return config.getAuthenticationManager();
	}
	@Bean
    public ModelMapper modelMapper() {
        return new ModelMapper();
    }
}
